<?php
// talents/index.php — Daftar Talent
require_once '../config.php';

$pageTitle = 'Data Talent — Finance HQ';
$conn      = db_connect();
$msg       = '';
$msg_type  = '';

// ── Handle DELETE ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_verify();
    $del_id = (int)($_POST['id'] ?? 0);
    if ($del_id > 0) {
        $st = $conn->prepare("DELETE FROM talents WHERE id = ?");
        if ($st) {
            $st->bind_param('i', $del_id);
            if ($st->execute() && $st->affected_rows > 0) {
                $msg = 'Talent berhasil dihapus (beserta semua log-nya).'; $msg_type = 'success';
            } else {
                $msg = 'Gagal menghapus atau talent tidak ditemukan.'; $msg_type = 'error';
            }
            $st->close();
        } else {
            $msg = 'DB error.'; $msg_type = 'error';
        }
    }
}

// ── Fetch Talents + Log Count ─────────────────────────────
$res = $conn->query("
    SELECT t.id, t.name, t.role, t.created_at,
           COUNT(tl.id)            AS log_count,
           COALESCE(SUM(tl.income),0) AS total_income,
           COALESCE(AVG(tl.rating),0) AS avg_rating
    FROM talents t
    LEFT JOIN talent_logs tl ON tl.talent_id = t.id
    GROUP BY t.id
    ORDER BY t.name ASC
");
$talents = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>🎭 Data Talent</h1>
    <p><?= count($talents) ?> talent terdaftar</p>
  </div>
  <a href="add.php" class="btn btn-primary">＋ Tambah Talent</a>
</div>

<?php if ($msg): ?>
  <div class="alert alert-<?= e($msg_type) ?>"><?= e($msg) ?></div>
<?php endif; ?>
<?php if (($_GET['added'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Talent berhasil ditambahkan.</div>
<?php endif; ?>
<?php if (($_GET['edited'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Data talent berhasil diubah.</div>
<?php endif; ?>

<div class="table-wrap">
  <div class="table-toolbar">
    <h3>Daftar Talent</h3>
    <small><?= count($talents) ?> entri</small>
  </div>
  <div class="table-scroll">
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Nama</th>
        <th>Role</th>
        <th>Total Log</th>
        <th>Total Income</th>
        <th>Avg Rating</th>
        <th>Terdaftar</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($talents)): ?>
      <tr class="empty-row"><td colspan="8">📭 Belum ada talent terdaftar</td></tr>
    <?php else: ?>
      <?php foreach ($talents as $i => $t): ?>
      <tr>
        <td style="color:var(--muted)"><?= $i + 1 ?></td>
        <td style="font-weight:600;color:var(--text-bright)"><?= e($t['name']) ?></td>
        <td style="color:var(--muted)"><?= $t['role'] ? e($t['role']) : '—' ?></td>
        <td>
          <a href="<?= BASE_URL ?>/talent_logs/?talent_id=<?= (int)$t['id'] ?>"
             class="badge badge-info"><?= (int)$t['log_count'] ?> log</a>
        </td>
        <td class="amount-income"><?= rupiah((float)$t['total_income']) ?></td>
        <td>
          <?php if ((int)$t['log_count'] > 0): ?>
            <span class="badge badge-info"><?= number_format((float)$t['avg_rating'], 1) ?></span>
          <?php else: ?>
            <span style="color:var(--muted)">—</span>
          <?php endif; ?>
        </td>
        <td style="color:var(--muted);font-size:12px">
          <?= e(date('d M Y', strtotime($t['created_at']))) ?>
        </td>
        <td>
          <div style="display:flex;gap:5px">
            <a href="edit.php?id=<?= (int)$t['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" onsubmit="return confirm('Hapus talent <?= e(addslashes($t['name'])) ?> dan SEMUA log-nya?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<?php require_once '../footer.php'; ?>
