<?php
// talents/add.php — Tambah Talent Baru
require_once '../config.php';

$pageTitle = 'Tambah Talent — Finance HQ';
$errors    = [];
$form      = ['name' => '', 'role' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $name = trim($_POST['name'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $form = compact('name', 'role');

    if ($name === '') {
        $errors[] = 'Nama talent tidak boleh kosong.';
    } elseif (strlen($name) > 150) {
        $errors[] = 'Nama terlalu panjang (maks 150 karakter).';
    }
    if (strlen($role) > 100) {
        $errors[] = 'Role terlalu panjang (maks 100 karakter).';
    }

    if (empty($errors)) {
        $conn = db_connect();
        $stmt = $conn->prepare("INSERT INTO talents (name, role) VALUES (?, ?)");
        if (!$stmt) {
            $errors[] = 'DB prepare error.';
        } else {
            $role_val = $role !== '' ? $role : null;
            $stmt->bind_param('ss', $name, $role_val);
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                header('Location: ' . BASE_URL . '/talents/?added=1');
                exit;
            } else {
                $errors[] = 'Gagal menyimpan ke database.';
                error_log('talents/add DB error: ' . $stmt->error);
                $stmt->close();
            }
            $conn->close();
        }
    }
}

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>＋ Tambah Talent</h1>
    <p>Daftarkan talent baru</p>
  </div>
  <a href="<?= BASE_URL ?>/talents/" class="btn btn-ghost">← Kembali</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">⚠️ <?= implode(' | ', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="form-card" style="max-width:520px">
  <h3>Form Talent Baru</h3>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid cols-1">
      <div class="form-group">
        <label for="name">Nama Talent *</label>
        <input type="text" name="name" id="name"
               value="<?= e($form['name']) ?>"
               placeholder="cth: Luna Star" maxlength="150" required>
      </div>
      <div class="form-group">
        <label for="role">Role / Posisi</label>
        <input type="text" name="role" id="role"
               value="<?= e($form['role']) ?>"
               placeholder="cth: Live Streamer" maxlength="100">
      </div>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan</button>
      <a href="<?= BASE_URL ?>/talents/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<?php require_once '../footer.php'; ?>
