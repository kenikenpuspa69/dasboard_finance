<?php
// talents/edit.php — Edit Data Talent
require_once '../config.php';

$pageTitle = 'Edit Talent — Finance HQ';
$errors    = [];

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . '/talents/');
    exit;
}

$conn = db_connect();

$st = $conn->prepare("SELECT * FROM talents WHERE id = ?");
if (!$st) { $conn->close(); header('Location: ' . BASE_URL . '/talents/'); exit; }
$st->bind_param('i', $id);
$st->execute();
$talent = $st->get_result()->fetch_assoc();
$st->close();

if (!$talent) {
    $conn->close();
    header('Location: ' . BASE_URL . '/talents/?notfound=1');
    exit;
}

$form = [
    'name' => $talent['name'],
    'role' => $talent['role'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $name = trim($_POST['name'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $form = compact('name', 'role');

    if ($name === '') {
        $errors[] = 'Nama talent tidak boleh kosong.';
    } elseif (strlen($name) > 150) {
        $errors[] = 'Nama terlalu panjang (maks 150 karakter).';
    }
    if (strlen($role) > 100) {
        $errors[] = 'Role terlalu panjang (maks 100 karakter).';
    }

    if (empty($errors)) {
        $role_val = $role !== '' ? $role : null;
        $stmt     = $conn->prepare("UPDATE talents SET name=?, role=? WHERE id=?");
        if (!$stmt) {
            $errors[] = 'DB prepare error.';
        } else {
            $stmt->bind_param('ssi', $name, $role_val, $id);
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                header('Location: ' . BASE_URL . '/talents/?edited=1');
                exit;
            } else {
                $errors[] = 'Gagal menyimpan perubahan.';
                error_log('talents/edit DB error: ' . $stmt->error);
                $stmt->close();
            }
        }
    }
}
$conn->close();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>✏️ Edit Talent</h1>
    <p>ID #<?= $id ?> — <?= e($talent['name']) ?></p>
  </div>
  <a href="<?= BASE_URL ?>/talents/" class="btn btn-ghost">← Kembali</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">⚠️ <?= implode(' | ', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="form-card" style="max-width:520px">
  <h3>Form Edit Talent</h3>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid cols-1">
      <div class="form-group">
        <label for="name">Nama Talent *</label>
        <input type="text" name="name" id="name"
               value="<?= e($form['name']) ?>"
               maxlength="150" required>
      </div>
      <div class="form-group">
        <label for="role">Role / Posisi</label>
        <input type="text" name="role" id="role"
               value="<?= e($form['role']) ?>"
               maxlength="100">
      </div>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
      <a href="<?= BASE_URL ?>/talents/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<?php require_once '../footer.php'; ?>
