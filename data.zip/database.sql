-- ============================================================
-- Finance Dashboard & Talent Analytics
-- Charset: utf8mb4 | Timezone: Asia/Jakarta
-- Jalankan di phpMyAdmin tab SQL (tanpa baris CREATE DATABASE)
-- ============================================================

-- -------------------------------------------------------
-- Tabel: settings (saldo awal & konfigurasi lainnya)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key_name`   VARCHAR(100) NOT NULL UNIQUE,
  `value`      TEXT NOT NULL DEFAULT '',
  `label`      VARCHAR(200) DEFAULT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default saldo awal = 0
INSERT IGNORE INTO `settings` (`key_name`, `value`, `label`)
VALUES ('saldo_awal', '0', 'Saldo Awal / Modal');

-- -------------------------------------------------------
-- Tabel: transactions
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `transactions` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `type`       ENUM('income','expense') NOT NULL,
  `category`   VARCHAR(100) NOT NULL,
  `amount`     BIGINT UNSIGNED NOT NULL,
  `note`       TEXT,
  `date`       DATE NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Tabel: talents
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `talents` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`       VARCHAR(150) NOT NULL,
  `role`       VARCHAR(100) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- Tabel: talent_logs
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `talent_logs` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `talent_id`  INT UNSIGNED NOT NULL,
  `perform`    VARCHAR(255) DEFAULT NULL,
  `views`      INT UNSIGNED DEFAULT 0,
  `income`     BIGINT UNSIGNED DEFAULT 0,
  `rating`     DECIMAL(5,2) DEFAULT 0.00,
  `duration`   VARCHAR(50) DEFAULT NULL,
  `log_date`   DATE NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_talent` FOREIGN KEY (`talent_id`)
    REFERENCES `talents`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
