<?php
// settings.php — Pengaturan Aplikasi (Saldo Awal)
require_once __DIR__ . '/config.php';

$pageTitle = 'Pengaturan — Finance HQ';
$msg       = '';
$msg_type  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $saldo_awal = trim($_POST['saldo_awal'] ?? '');

    // Validasi: ctype_digit tidak menerima string kosong — handle eksplisit
    if ($saldo_awal === '' || !ctype_digit($saldo_awal)) {
        $msg      = 'Saldo awal harus berupa angka bulat ≥ 0 (tanpa koma atau titik).';
        $msg_type = 'error';
    } else {
        if (set_setting('saldo_awal', (string)(int)$saldo_awal)) {
            $msg      = 'Pengaturan berhasil disimpan.';
            $msg_type = 'success';
        } else {
            $msg      = 'Gagal menyimpan pengaturan ke database.';
            $msg_type = 'error';
        }
    }
}

// Ambil nilai terkini setelah kemungkinan save
$saldo_awal_val = get_setting('saldo_awal', '0');

require_once __DIR__ . '/header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>⚙️ Pengaturan</h1>
    <p>Konfigurasi saldo awal dan modal usaha</p>
  </div>
  <a href="<?= BASE_URL ?>/" class="btn btn-ghost">← Dashboard</a>
</div>

<?php if ($msg): ?>
  <div class="alert alert-<?= e($msg_type) ?>"><?= e($msg) ?></div>
<?php endif; ?>

<div class="form-card" style="max-width:520px">
  <h3>💰 Saldo Awal / Modal</h3>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid cols-1">
      <div class="form-group">
        <label for="saldo_awal">Nominal Saldo Awal (Rp)</label>
        <input type="number"
               name="saldo_awal"
               id="saldo_awal"
               value="<?= e($saldo_awal_val) ?>"
               min="0" step="1000"
               placeholder="cth: 1000000"
               required>
        <small style="color:var(--muted);font-size:11px">
          Saldo ini dijumlahkan ke total pemasukan sebagai modal awal.
          Nilai saat ini: <strong style="color:var(--green)"><?= rupiah((int)$saldo_awal_val) ?></strong>
        </small>
      </div>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan</button>
      <a href="<?= BASE_URL ?>/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<!-- Ringkasan Posisi Keuangan -->
<div class="form-card" style="max-width:520px;margin-top:0">
  <h3>📊 Ringkasan Posisi Keuangan</h3>
  <?php
    $conn  = db_connect();
    $res   = $conn->query("
        SELECT
          COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS inc,
          COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS exp
        FROM transactions
    ");
    if (!$res) {
        $conn->close();
        echo '<p style="color:var(--red)">Gagal memuat ringkasan.</p>';
    } else {
        $fin   = $res->fetch_assoc();
        $conn->close();
        $modal = (int)$saldo_awal_val;
        $inc   = (int)$fin['inc'];
        $exp   = (int)$fin['exp'];
        $saldo = $modal + $inc - $exp;
        $roi   = $modal > 0 ? round(($saldo - $modal) / $modal * 100, 1) : null;
  ?>
  <div style="display:grid;gap:10px;font-size:13px">
    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)">
      <span style="color:var(--muted)">Modal Awal</span>
      <span style="color:var(--accent);font-weight:600"><?= rupiah($modal) ?></span>
    </div>
    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)">
      <span style="color:var(--muted)">Total Pemasukan</span>
      <span style="color:var(--green);font-weight:600"><?= rupiah($inc) ?></span>
    </div>
    <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)">
      <span style="color:var(--muted)">Total Pengeluaran</span>
      <span style="color:var(--red);font-weight:600"><?= rupiah($exp) ?></span>
    </div>
    <div style="display:flex;justify-content:space-between;padding:10px 0">
      <span style="color:var(--text-bright);font-weight:700">Saldo Bersih</span>
      <span style="color:<?= $saldo >= 0 ? 'var(--green)' : 'var(--red)' ?>;font-weight:700;font-size:15px">
        <?= rupiah(abs($saldo)) ?><?= $saldo < 0 ? ' (DEFISIT)' : '' ?>
      </span>
    </div>
    <?php if ($roi !== null): ?>
    <div style="display:flex;justify-content:space-between;padding:8px 12px;background:var(--surface2);border-radius:8px">
      <span style="color:var(--muted)">ROI dari Modal</span>
      <span style="color:<?= $roi >= 0 ? 'var(--green)' : 'var(--red)' ?>;font-weight:600">
        <?= $roi >= 0 ? '+' : '' ?><?= $roi ?>%
      </span>
    </div>
    <?php endif; ?>
  </div>
  <?php } ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
