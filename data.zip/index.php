<?php
// index.php — Dashboard Utama Finance HQ
require_once __DIR__ . '/config.php';

$pageTitle = 'Dashboard — Finance HQ';
$conn      = db_connect();

// ── Saldo Awal (Modal) ────────────────────────────────────
$saldo_awal = (int)get_setting('saldo_awal', '0');

// ── Summary Keuangan Keseluruhan ──────────────────────────
$res_all = $conn->query("
    SELECT
      COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS total_inc,
      COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS total_exp,
      COUNT(*) AS total_tx
    FROM transactions
");
$all = $res_all ? $res_all->fetch_assoc() : ['total_inc'=>0,'total_exp'=>0,'total_tx'=>0];
$saldo_bersih = $saldo_awal + (int)$all['total_inc'] - (int)$all['total_exp'];

// ── Bulan Ini ─────────────────────────────────────────────
$bulan_ini = date('Y-m');
$stmt_m = $conn->prepare("
    SELECT
      COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS inc,
      COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS exp,
      COUNT(*) AS tx
    FROM transactions
    WHERE DATE_FORMAT(date,'%Y-%m') = ?
");
$stmt_m->bind_param('s', $bulan_ini);
$stmt_m->execute();
$month = $stmt_m->get_result()->fetch_assoc();
$stmt_m->close();

// ── Chart: 6 Bulan Terakhir ───────────────────────────────
$stmt_ch = $conn->prepare("
    SELECT
      DATE_FORMAT(date,'%Y-%m') AS m,
      COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS inc,
      COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS exp
    FROM transactions
    WHERE date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY m ORDER BY m ASC
");
$stmt_ch->execute();
$chart_rows   = $stmt_ch->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_ch->close();

$chart_labels  = [];
$chart_income  = [];
$chart_expense = [];
foreach ($chart_rows as $cr) {
    $dt              = DateTime::createFromFormat('Y-m', $cr['m']);
    $chart_labels[]  = $dt ? $dt->format('M Y') : $cr['m'];
    $chart_income[]  = (int)$cr['inc'];
    $chart_expense[] = (int)$cr['exp'];
}

// ── Chart: Kategori Pengeluaran (Pie) ─────────────────────
$stmt_pie = $conn->prepare("
    SELECT category, SUM(amount) AS total
    FROM transactions
    WHERE type='expense' AND DATE_FORMAT(date,'%Y-%m') = ?
    GROUP BY category ORDER BY total DESC LIMIT 8
");
$stmt_pie->bind_param('s', $bulan_ini);
$stmt_pie->execute();
$pie_rows = $stmt_pie->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_pie->close();

$pie_labels = array_column($pie_rows, 'category');
$pie_values = array_map(fn($r) => (int)$r['total'], $pie_rows);

// ── Transaksi Terbaru ─────────────────────────────────────
$res_recent = $conn->query("
    SELECT id, type, category, amount, note, date
    FROM transactions
    ORDER BY date DESC, created_at DESC
    LIMIT 8
");
$recent_tx = $res_recent ? $res_recent->fetch_all(MYSQLI_ASSOC) : [];

// ── Talent Summary ────────────────────────────────────────
$res_talent = $conn->query("
    SELECT COUNT(*) AS total_talent FROM talents
");
$total_talent = $res_talent ? (int)$res_talent->fetch_assoc()['total_talent'] : 0;

$stmt_tlog = $conn->prepare("
    SELECT COUNT(*) AS c, COALESCE(SUM(income),0) AS ti
    FROM talent_logs
    WHERE DATE_FORMAT(log_date,'%Y-%m') = ?
");
$stmt_tlog->bind_param('s', $bulan_ini);
$stmt_tlog->execute();
$tlog_month = $stmt_tlog->get_result()->fetch_assoc() ?? ['c'=>0,'ti'=>0];
$stmt_tlog->close();

$conn->close();

require_once __DIR__ . '/header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>📊 Dashboard</h1>
    <p>Ringkasan keuangan &amp; performa talent — <?= date('F Y') ?></p>
  </div>
</div>

<!-- Summary Cards -->
<div class="cards">
  <div class="card green">
    <div class="card-icon">💰</div>
    <div class="card-label">Saldo Bersih</div>
    <div class="card-value"><?= rupiah($saldo_bersih) ?></div>
    <div class="card-sub">Modal + pemasukan − pengeluaran</div>
  </div>
  <div class="card green">
    <div class="card-icon">📈</div>
    <div class="card-label">Pemasukan Bulan Ini</div>
    <div class="card-value"><?= rupiah((float)$month['inc']) ?></div>
    <div class="card-sub"><?= (int)$month['tx'] ?> transaksi bulan ini</div>
  </div>
  <div class="card red">
    <div class="card-icon">📉</div>
    <div class="card-label">Pengeluaran Bulan Ini</div>
    <div class="card-value"><?= rupiah((float)$month['exp']) ?></div>
  </div>
  <div class="card yellow">
    <div class="card-icon">🎤</div>
    <div class="card-label">Income Talent Bulan Ini</div>
    <div class="card-value"><?= rupiah((float)$tlog_month['ti']) ?></div>
    <div class="card-sub"><?= (int)$tlog_month['c'] ?> log — <a href="<?= BASE_URL ?>/talent_logs/" style="color:inherit;text-decoration:underline">Lihat Laporan →</a></div>
  </div>
  <div class="card accent">
    <div class="card-icon">🎭</div>
    <div class="card-label">Talent Aktif</div>
    <div class="card-value"><?= $total_talent ?></div>
  </div>
</div>

<!-- Charts -->
<?php if (!empty($chart_labels)): ?>
<div class="chart-grid">
  <div class="chart-card">
    <h3>📊 Trend Keuangan 6 Bulan</h3>
    <canvas id="trendChart" height="100"></canvas>
  </div>
  <?php if (!empty($pie_values)): ?>
  <div class="chart-card">
    <h3>🍩 Komposisi Pengeluaran Bulan Ini</h3>
    <canvas id="pieChart" height="100"></canvas>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Transaksi Terbaru -->
<div class="table-wrap">
  <div class="table-toolbar">
    <h3>Transaksi Terbaru</h3>
    <a href="<?= BASE_URL ?>/transactions/" class="btn btn-ghost btn-sm">Lihat Semua →</a>
  </div>
  <div class="table-scroll">
  <table>
    <thead>
      <tr>
        <th>Tanggal</th>
        <th>Tipe</th>
        <th>Kategori</th>
        <th>Jumlah</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($recent_tx)): ?>
      <tr class="empty-row"><td colspan="5">📭 Belum ada transaksi</td></tr>
    <?php else: ?>
      <?php foreach ($recent_tx as $tx): ?>
      <tr>
        <td><?= e(date('d M Y', strtotime($tx['date']))) ?></td>
        <td>
          <span class="badge badge-<?= $tx['type'] === 'income' ? 'income' : 'expense' ?>">
            <?= $tx['type'] === 'income' ? '↑ Income' : '↓ Expense' ?>
          </span>
        </td>
        <td><?= e($tx['category']) ?></td>
        <td class="amount-<?= $tx['type'] ?>"><?= rupiah((float)$tx['amount']) ?></td>
        <td style="color:var(--muted)"><?= $tx['note'] ? e($tx['note']) : '—' ?></td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<?php if (!empty($chart_labels)): ?>
<script>
Chart.defaults.color = '#8b949e';
Chart.defaults.borderColor = '#30363d';

(function(){
  var ctx = document.getElementById('trendChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: <?= json_encode($chart_labels) ?>,
      datasets: [
        {
          label: 'Pemasukan',
          data: <?= json_encode($chart_income) ?>,
          borderColor: '#3fb950', backgroundColor: 'rgba(63,185,80,.15)',
          fill: true, tension: 0.4, pointRadius: 4,
        },
        {
          label: 'Pengeluaran',
          data: <?= json_encode($chart_expense) ?>,
          borderColor: '#f85149', backgroundColor: 'rgba(248,81,73,.1)',
          fill: true, tension: 0.4, pointRadius: 4,
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      interaction: { mode: 'index', intersect: false },
      plugins: { legend: { position: 'top' } },
      scales: {
        x: { grid: { color: '#21262d' } },
        y: {
          grid: { color: '#21262d' },
          ticks: { callback: function(v){ return 'Rp'+(v/1000).toFixed(0)+'K'; } }
        }
      }
    }
  });
})();

<?php if (!empty($pie_values)): ?>
(function(){
  var ctx = document.getElementById('pieChart');
  if (!ctx) return;
  var colors = ['#f85149','#e3b341','#7c83fd','#3fb950','#58a6ff','#a78bfa','#fb923c','#34d399'];
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: <?= json_encode($pie_labels) ?>,
      datasets: [{
        data: <?= json_encode($pie_values) ?>,
        backgroundColor: colors.slice(0, <?= count($pie_values) ?>),
        borderColor: '#161b22',
        borderWidth: 2,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10 } },
        tooltip: {
          callbacks: {
            label: function(ctx){
              return ctx.label + ': Rp' + ctx.parsed.toLocaleString('id-ID');
            }
          }
        }
      }
    }
  });
})();
<?php endif; ?>
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
