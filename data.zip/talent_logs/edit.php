<?php
// talent_logs/edit.php — Edit Log Performa Talent
require_once '../config.php';

$pageTitle = 'Edit Log Performa — Finance HQ';
$errors    = [];

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . '/talent_logs/');
    exit;
}

$conn = db_connect();

$st = $conn->prepare("SELECT * FROM talent_logs WHERE id = ?");
if (!$st) {
    $conn->close();
    header('Location: ' . BASE_URL . '/talent_logs/');
    exit;
}
$st->bind_param('i', $id);
$st->execute();
$log = $st->get_result()->fetch_assoc();
$st->close();

if (!$log) {
    $conn->close();
    header('Location: ' . BASE_URL . '/talent_logs/?notfound=1');
    exit;
}

$form = [
    'talent_id'       => (string)$log['talent_id'],
    'followers_baru'  => (string)$log['followers_baru'],
    'views'           => (string)$log['views'],
    'income'          => (string)$log['income'],
    'room'            => $log['room']            ?? '',
    'kategori_perform'=> $log['kategori_perform'] ?? '',
    'log_date'        => $log['log_date'],
];

$res_tl  = $conn->query("SELECT id, name, role FROM talents ORDER BY name ASC");
$talents = $res_tl ? $res_tl->fetch_all(MYSQLI_ASSOC) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $talent_id        = (int)($_POST['talent_id']        ?? 0);
    $followers_baru   = trim($_POST['followers_baru']    ?? '');
    $views            = trim($_POST['views']             ?? '');
    $income           = trim($_POST['income']            ?? '');
    $room             = trim($_POST['room']              ?? '');
    $kategori_perform = trim($_POST['kategori_perform']  ?? '');
    $log_date         = trim($_POST['log_date']          ?? '');

    $form = [
        'talent_id'       => (string)$talent_id,
        'followers_baru'  => $followers_baru,
        'views'           => $views,
        'income'          => $income,
        'room'            => $room,
        'kategori_perform'=> $kategori_perform,
        'log_date'        => $log_date,
    ];

    // Validasi
    if ($talent_id <= 0) {
        $errors[] = 'Pilih talent terlebih dahulu.';
    }
    if (!ctype_digit($followers_baru) || (int)$followers_baru < 0) {
        $errors[] = 'Followers Baru harus berupa angka ≥ 0.';
    }
    if (!ctype_digit($views) || (int)$views < 0) {
        $errors[] = 'Views harus berupa angka ≥ 0.';
    }
    if (!ctype_digit($income) || (int)$income < 0) {
        $errors[] = 'Income harus berupa angka ≥ 0.';
    }
    if (strlen($room) > 100) {
        $errors[] = 'Room terlalu panjang (maks 100 karakter).';
    }
    if (!in_array($kategori_perform, ['Solo', 'Duet'], true)) {
        $errors[] = 'Kategori Perform harus Solo atau Duet.';
    }
    $date_obj = DateTime::createFromFormat('Y-m-d', $log_date);
    if (!$date_obj || $date_obj->format('Y-m-d') !== $log_date) {
        $errors[] = 'Format tanggal tidak valid.';
    }

    if (empty($errors)) {
        $fb  = (int)$followers_baru;
        $v   = (int)$views;
        $inc = (int)$income;
        $rm  = substr(strip_tags($room), 0, 100);
        $kat = $kategori_perform;

        $stmt = $conn->prepare(
            "UPDATE talent_logs
             SET talent_id=?, followers_baru=?, views=?, income=?, room=?, kategori_perform=?, log_date=?
             WHERE id=?"
        );
        if (!$stmt) {
            $errors[] = 'DB prepare error.';
        } else {
            $stmt->bind_param('iiiisssi', $talent_id, $fb, $v, $inc, $rm, $kat, $log_date, $id);
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                header('Location: ' . BASE_URL . '/talent_logs/?edited=1');
                exit;
            } else {
                $errors[] = 'Gagal menyimpan perubahan.';
                error_log('talent_logs/edit DB error: ' . $stmt->error);
                $stmt->close();
            }
        }
    }
}
$conn->close();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>✏️ Edit Log Performa</h1>
    <p>Log ID #<?= $id ?> — <?= e(date('d M Y', strtotime($log['log_date']))) ?></p>
  </div>
  <a href="<?= BASE_URL ?>/talent_logs/" class="btn btn-ghost">← Kembali</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">⚠️ <?= implode(' | ', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="form-card">
  <h3>Form Edit Log</h3>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid">

      <!-- Talent -->
      <div class="form-group">
        <label for="talent_id">Talent *</label>
        <select name="talent_id" id="talent_id" required>
          <option value="">-- Pilih Talent --</option>
          <?php foreach ($talents as $t): ?>
            <option value="<?= (int)$t['id'] ?>"
              <?= (string)$t['id'] === $form['talent_id'] ? 'selected' : '' ?>>
              <?= e($t['name']) ?><?= $t['role'] ? ' — ' . e($t['role']) : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Tanggal -->
      <div class="form-group">
        <label for="log_date">Tanggal *</label>
        <input type="date" name="log_date" id="log_date"
               value="<?= e($form['log_date']) ?>" required>
      </div>

      <!-- Followers Baru -->
      <div class="form-group">
        <label for="followers_baru">Followers Baru *</label>
        <input type="number" name="followers_baru" id="followers_baru"
               value="<?= e($form['followers_baru']) ?>"
               min="0" step="1" required>
      </div>

      <!-- Views -->
      <div class="form-group">
        <label for="views">Views *</label>
        <input type="number" name="views" id="views"
               value="<?= e($form['views']) ?>"
               min="0" step="1" required>
      </div>

      <!-- Income -->
      <div class="form-group">
        <label for="income">Income (Rp) *</label>
        <input type="number" name="income" id="income"
               value="<?= e($form['income']) ?>"
               min="0" step="1" required>
      </div>

      <!-- Room -->
      <div class="form-group">
        <label for="room">Room</label>
        <input type="text" name="room" id="room"
               value="<?= e($form['room']) ?>"
               maxlength="100">
      </div>

      <!-- Kategori Perform -->
      <div class="form-group">
        <label for="kategori_perform">Kategori Perform *</label>
        <select name="kategori_perform" id="kategori_perform" required>
          <option value="">-- Pilih Kategori --</option>
          <option value="Solo" <?= $form['kategori_perform'] === 'Solo' ? 'selected' : '' ?>>Solo</option>
          <option value="Duet" <?= $form['kategori_perform'] === 'Duet' ? 'selected' : '' ?>>Duet</option>
        </select>
      </div>

    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
      <a href="<?= BASE_URL ?>/talent_logs/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<?php require_once '../footer.php'; ?>
