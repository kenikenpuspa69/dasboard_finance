<?php
// talent_logs/index.php — Daftar Talent Logs
require_once '../config.php';

$pageTitle = 'Talent Logs — Finance HQ';
$conn      = db_connect();
$msg       = '';
$msg_type  = '';

// ── Handle DELETE ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM talent_logs WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param('i', $id);
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                $msg = 'Log berhasil dihapus.'; $msg_type = 'success';
            } else {
                $msg = 'Gagal menghapus log atau log tidak ditemukan.'; $msg_type = 'error';
            }
            $stmt->close();
        } else {
            $msg = 'DB error: ' . htmlspecialchars($conn->error); $msg_type = 'error';
        }
    } else {
        $msg = 'ID tidak valid.'; $msg_type = 'error';
    }
}

// ── Filter by Talent ──────────────────────────────────────
$filter_tid  = (int)($_GET['talent_id'] ?? 0);
$talent_name = '';

if ($filter_tid > 0) {
    $st = $conn->prepare("SELECT name FROM talents WHERE id = ?");
    if ($st) {
        $st->bind_param('i', $filter_tid);
        $st->execute();
        $tn = $st->get_result()->fetch_assoc();
        $st->close();
        $talent_name = $tn ? $tn['name'] : '';
        if ($talent_name === '') $filter_tid = 0;
    }
}

$res_talents = $conn->query("SELECT id, name FROM talents ORDER BY name ASC");
$all_talents = $res_talents ? $res_talents->fetch_all(MYSQLI_ASSOC) : [];

// ── Fetch Logs ────────────────────────────────────────────
if ($filter_tid > 0) {
    $stmt_q = $conn->prepare("
        SELECT tl.*, t.name AS talent_name
        FROM talent_logs tl JOIN talents t ON t.id = tl.talent_id
        WHERE tl.talent_id = ?
        ORDER BY tl.log_date DESC, tl.created_at DESC
    ");
    if (!$stmt_q) {
        $conn->close();
        die('DB prepare error: ' . htmlspecialchars($conn->error));
    }
    $stmt_q->bind_param('i', $filter_tid);
} else {
    $stmt_q = $conn->prepare("
        SELECT tl.*, t.name AS talent_name
        FROM talent_logs tl JOIN talents t ON t.id = tl.talent_id
        ORDER BY tl.log_date DESC, tl.created_at DESC
        LIMIT 100
    ");
    if (!$stmt_q) {
        $conn->close();
        die('DB prepare error: ' . htmlspecialchars($conn->error));
    }
}
$stmt_q->execute();
$logs = $stmt_q->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_q->close();

// ── Summary ───────────────────────────────────────────────
if ($filter_tid > 0) {
    $stmt_sum = $conn->prepare("
        SELECT COUNT(*) AS c,
               COALESCE(SUM(income),0)         AS ti,
               COALESCE(SUM(views),0)           AS tv,
               COALESCE(SUM(followers_baru),0)  AS tf
        FROM talent_logs WHERE talent_id = ?
    ");
    if (!$stmt_sum) {
        $conn->close();
        die('DB prepare error.');
    }
    $stmt_sum->bind_param('i', $filter_tid);
    $stmt_sum->execute();
    $sum = $stmt_sum->get_result()->fetch_assoc();
    $stmt_sum->close();
} else {
    $res_sum = $conn->query("
        SELECT COUNT(*) AS c,
               COALESCE(SUM(income),0)        AS ti,
               COALESCE(SUM(views),0)          AS tv,
               COALESCE(SUM(followers_baru),0) AS tf
        FROM talent_logs
    ");
    $sum = $res_sum ? $res_sum->fetch_assoc() : ['c'=>0,'ti'=>0,'tv'=>0,'tf'=>0];
}

// ── Chart data (jika filter talent aktif) ─────────────────
$chart_labels = [];
$chart_income = [];
$chart_views  = [];

if ($filter_tid > 0) {
    $stmt_ch = $conn->prepare("
        SELECT log_date,
               SUM(income)         AS inc,
               SUM(views)          AS vws,
               SUM(followers_baru) AS flw
        FROM talent_logs WHERE talent_id = ?
        GROUP BY log_date ORDER BY log_date ASC
        LIMIT 30
    ");
    if ($stmt_ch) {
        $stmt_ch->bind_param('i', $filter_tid);
        $stmt_ch->execute();
        $chrows = $stmt_ch->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt_ch->close();
        foreach ($chrows as $ch) {
            $chart_labels[] = date('d M', strtotime($ch['log_date']));
            $chart_income[] = (int)$ch['inc'];
            $chart_views[]  = (int)$ch['vws'];
        }
    }
}

$conn->close();

// ── Chart Script ──────────────────────────────────────────
ob_start();
if ($filter_tid > 0 && !empty($chart_labels)):
?>
Chart.defaults.color = '#8b949e';
Chart.defaults.borderColor = '#30363d';

(function(){
  var ctx = document.getElementById('trendChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: <?= json_encode($chart_labels) ?>,
      datasets: [
        {
          label: 'Income (Rp)',
          data: <?= json_encode($chart_income) ?>,
          borderColor: '#7c83fd', backgroundColor: 'rgba(124,131,253,.15)',
          fill: true, tension: 0.4, pointRadius: 4, yAxisID: 'yInc',
        },
        {
          label: 'Views',
          data: <?= json_encode($chart_views) ?>,
          borderColor: '#3fb950', backgroundColor: 'rgba(63,185,80,.1)',
          fill: true, tension: 0.4, pointRadius: 4, yAxisID: 'yViews',
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      interaction: { mode: 'index', intersect: false },
      plugins: { legend: { position: 'top' } },
      scales: {
        x: { grid: { color: '#21262d' } },
        yInc: {
          position: 'left', grid: { color: '#21262d' },
          ticks: { callback: function(v){ return 'Rp'+(v/1000).toFixed(0)+'K'; } }
        },
        yViews: {
          position: 'right', grid: { drawOnChartArea: false },
          ticks: { callback: function(v){ return v+' views'; } }
        }
      }
    }
  });
})();
<?php
endif;
$chartScript = ob_get_clean();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>📈 Talent Logs</h1>
    <p><?= $talent_name ? 'Filter: <strong>' . e($talent_name) . '</strong> — ' : '' ?><?= (int)$sum['c'] ?> log</p>
  </div>
  <a href="<?= BASE_URL ?>/talent_logs/add.php<?= $filter_tid > 0 ? '?talent_id=' . $filter_tid : '' ?>"
     class="btn btn-primary">＋ Input Log</a>
</div>

<?php if ($msg): ?>
  <div class="alert alert-<?= e($msg_type) ?>"><?= e($msg) ?></div>
<?php endif; ?>
<?php if (($_GET['added'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Log performa berhasil ditambahkan.</div>
<?php endif; ?>
<?php if (($_GET['edited'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Log performa berhasil diubah.</div>
<?php endif; ?>

<!-- Summary Cards — Income Talent terpisah dari keuangan umum -->
<div class="cards" style="margin-bottom:18px">
  <div class="card green">
    <div class="card-label">Total Income Talent</div>
    <div class="card-value"><?= rupiah((float)$sum['ti']) ?></div>
    <div class="card-sub">Dari log talent (bukan transaksi umum)</div>
  </div>
  <div class="card accent">
    <div class="card-label">Total Views</div>
    <div class="card-value"><?= number_format((int)$sum['tv']) ?></div>
  </div>
  <div class="card yellow">
    <div class="card-label">Total Followers Baru</div>
    <div class="card-value"><?= number_format((int)$sum['tf']) ?></div>
  </div>
</div>

<!-- Chart (hanya tampil jika filter per talent aktif) -->
<?php if ($filter_tid > 0 && !empty($chart_labels)): ?>
<div class="chart-grid" style="margin-bottom:22px">
  <div class="chart-card">
    <h3>📊 Trend Income &amp; Views — <?= e($talent_name) ?></h3>
    <canvas id="trendChart" height="110"></canvas>
  </div>
</div>
<?php endif; ?>

<!-- Filter -->
<div style="margin-bottom:16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
  <label style="color:var(--muted);font-size:13px">Filter:</label>
  <a href="?" class="btn btn-sm <?= $filter_tid===0 ? 'btn-primary' : 'btn-ghost' ?>">Semua</a>
  <?php foreach ($all_talents as $t): ?>
    <a href="?talent_id=<?= (int)$t['id'] ?>"
       class="btn btn-sm <?= $filter_tid===(int)$t['id'] ? 'btn-primary' : 'btn-ghost' ?>">
      <?= e($t['name']) ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="table-wrap">
  <div class="table-toolbar"><h3>Riwayat Log Performa</h3></div>
  <div class="table-scroll">
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Tanggal</th>
        <th>Talent</th>
        <th>Followers Baru</th>
        <th>Views</th>
        <th>Income</th>
        <th>Room</th>
        <th>Kategori</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($logs)): ?>
      <tr class="empty-row"><td colspan="9">📭 Belum ada log</td></tr>
    <?php else: ?>
      <?php foreach ($logs as $i => $log): ?>
      <tr>
        <td style="color:var(--muted)"><?= $i + 1 ?></td>
        <td><?= e(date('d M Y', strtotime($log['log_date']))) ?></td>
        <td style="font-weight:600;color:var(--text-bright)"><?= e($log['talent_name']) ?></td>
        <td><?= number_format((int)$log['followers_baru']) ?></td>
        <td><?= number_format((int)$log['views']) ?></td>
        <td class="amount-income"><?= rupiah((float)$log['income']) ?></td>
        <td style="color:var(--muted)"><?= e($log['room'] !== '' ? $log['room'] : '—') ?></td>
        <td><span class="badge badge-info"><?= e($log['kategori_perform'] ?? '—') ?></span></td>
        <td>
          <div style="display:flex;gap:5px">
            <a href="<?= BASE_URL ?>/talent_logs/edit.php?id=<?= (int)$log['id'] ?>"
               class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" onsubmit="return confirm('Hapus log ini?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$log['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<?php if ($chartScript): ?>
<script><?= $chartScript ?></script>
<?php endif; ?>
<?php require_once '../footer.php'; ?>
