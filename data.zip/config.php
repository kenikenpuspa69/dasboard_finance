<?php
// ============================================================
// config.php — Konfigurasi Utama Aplikasi
// ============================================================

// --- Database ---
define('DB_HOST', 'localhost');
define('DB_USER', 'medz4263_financeuser');
define('DB_PASS', 'Redipast369@');
define('DB_NAME', 'medz4263_financedb');

// --- Telegram Bot ---
define('BOT_TOKEN', '8503633765:AAH9gqzHJ20qoLfC1Bk6RSiyEn6JW2YFF_U');
define('ALLOWED_USER_ID', 1777821541);

// --- URL Aplikasi (tanpa trailing slash) ---
define('BASE_URL', '/dashboard_analytic');

// --- Timezone ---
date_default_timezone_set('Asia/Jakarta');

// --- Kategori Transaksi (FIX: didefinisikan di sini agar tersedia di semua file) ---
define('CATEGORIES_INCOME', [
    'Topup Star Tevi',
    'Withdraw Tevi',
    'Pemasukan Lainnya',
]);

define('CATEGORIES_EXPENSE', [
    'Order Star Tevi',
    'Pembayaran Talent',
    'Pembayaran Admin',
    'Tabungan',
    'Konsumsi',
    'Transportasi',
    'Operasional Talent',
    'Kasbon',
    'Pembayaran Lainnya',
]);

// ============================================================
// Fungsi Koneksi Database
// ============================================================
function db_connect(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        error_log('DB connect error: ' . $conn->connect_error);
        http_response_code(500);
        die('Koneksi database gagal. Silakan coba lagi nanti.');
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

// ============================================================
// Helper Functions
// ============================================================

/** Format angka ke format Rupiah */
function rupiah(int|float $amount): string {
    return 'Rp ' . number_format((float)$amount, 0, ',', '.');
}

/** Escape string untuk output HTML */
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/** Escape untuk Telegram HTML parse_mode */
function tgE(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/** Redirect dengan BASE_URL */
function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}

// ============================================================
// Settings Helper (FIX: fungsi get_setting & set_setting)
// ============================================================

/** Ambil nilai setting dari DB */
function get_setting(string $key, string $default = ''): string {
    $conn = db_connect();
    $stmt = $conn->prepare("SELECT value FROM settings WHERE key_name = ?");
    if (!$stmt) {
        $conn->close();
        return $default;
    }
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();
    return $row ? (string)$row['value'] : $default;
}

/** Simpan nilai setting ke DB (upsert) */
function set_setting(string $key, string $value): bool {
    $conn = db_connect();
    $stmt = $conn->prepare(
        "INSERT INTO settings (key_name, value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE value = VALUES(value)"
    );
    if (!$stmt) {
        $conn->close();
        return false;
    }
    $stmt->bind_param('ss', $key, $value);
    $ok = $stmt->execute();
    $stmt->close();
    $conn->close();
    return $ok;
}

// ============================================================
// Session & CSRF
// ============================================================

/** Start session jika belum aktif */
function session_start_once(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

/** Generate atau ambil CSRF token */
function csrf_token(): string {
    session_start_once();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Verifikasi CSRF token — die jika invalid */
function csrf_verify(): void {
    session_start_once();
    $token = $_POST['csrf_token'] ?? '';
    if (
        empty($token) ||
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        die('Permintaan tidak valid (CSRF check gagal).');
    }
}

/** Output hidden input CSRF untuk form */
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

// Mulai session sekali di sini (sebelum output apapun)
session_start_once();
