<?php
// header.php — Dipanggil dari setiap halaman
if (!defined('DB_HOST')) {
    require_once dirname(__FILE__) . '/config.php';
}

$current         = $_SERVER['PHP_SELF'];
$is_dashboard    = (basename($current) === 'index.php'
                    && strpos($current, '/transactions/') === false
                    && strpos($current, '/talents/')      === false
                    && strpos($current, '/talent_logs/')  === false
                    && strpos($current, '/settings')      === false);
$is_transactions = strpos($current, '/transactions/')  !== false;
$is_talents      = strpos($current, '/talents/')       !== false;
$is_talent_logs  = strpos($current, '/talent_logs/')   !== false;
$is_settings     = strpos($current, '/settings')       !== false;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Finance Dashboard') ?></title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<style>
/* ===================== RESET & BASE ===================== */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#0d1117;
  --surface:#161b22;
  --surface2:#21262d;
  --surface3:#2d333b;
  --border:#30363d;
  --text:#c9d1d9;
  --text-bright:#e6edf3;
  --muted:#8b949e;
  --accent:#7c83fd;
  --accent-dim:rgba(124,131,253,.15);
  --green:#3fb950;
  --green-dim:rgba(63,185,80,.15);
  --red:#f85149;
  --red-dim:rgba(248,81,73,.15);
  --yellow:#e3b341;
  --yellow-dim:rgba(227,179,65,.15);
  --blue:#58a6ff;
  --sidebar-w:230px;
  --topbar-h:52px;
  --radius:10px;
}
body{
  background:var(--bg);
  color:var(--text);
  font-family:'Segoe UI',system-ui,-apple-system,sans-serif;
  display:flex;
  min-height:100vh;
  font-size:14px;
}

/* ===================== MOBILE TOPBAR ===================== */
.topbar{
  display:none;
  position:fixed;
  top:0;left:0;right:0;
  height:var(--topbar-h);
  background:var(--surface);
  border-bottom:1px solid var(--border);
  z-index:200;
  align-items:center;
  padding:0 16px;
  gap:12px;
}
.topbar-brand{font-size:15px;font-weight:700;color:var(--text-bright);flex:1}
.topbar-brand span{
  background:linear-gradient(135deg,#7c83fd,#a78bfa);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.hamburger{
  background:none;border:1px solid var(--border);
  color:var(--text-bright);font-size:18px;cursor:pointer;
  padding:6px 10px;border-radius:7px;line-height:1;flex-shrink:0;
}
.hamburger:hover{background:var(--surface2)}

/* ===================== OVERLAY ===================== */
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99}
.sidebar-overlay.active{display:block}

/* ===================== SIDEBAR ===================== */
.sidebar{
  width:var(--sidebar-w);
  background:var(--surface);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;
  height:100vh;z-index:100;
  overflow-y:auto;
  transition:transform .25s ease;
}
.sidebar-brand{padding:18px 16px 16px;border-bottom:1px solid var(--border)}
.sidebar-brand .logo{
  font-size:15px;font-weight:700;color:var(--text-bright);
  display:flex;align-items:center;gap:9px;
}
.sidebar-brand .logo span{
  background:linear-gradient(135deg,#7c83fd,#a78bfa);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.sidebar-brand small{display:block;font-size:9px;color:var(--muted);margin-top:3px;padding-left:27px}
.sidebar-nav{padding:9px 0;flex:1}
.nav-section{
  padding:12px 16px 4px;font-size:10px;
  color:var(--muted);text-transform:uppercase;
  letter-spacing:1.2px;font-weight:600;
}
.nav-link{
  display:flex;align-items:center;gap:10px;
  padding:9px 16px;color:var(--muted);
  text-decoration:none;font-size:12px;
  transition:all .15s;
  border-left:3px solid transparent;margin:1px 0;
}
.nav-link .icon{font-size:15px;width:20px;text-align:center;flex-shrink:0}
.nav-link:hover{background:var(--surface2);color:var(--text-bright);border-left-color:var(--border)}
.nav-link.active{background:var(--accent-dim);color:var(--accent);border-left-color:var(--accent);font-weight:600}
.sidebar-footer{padding:12px 16px;border-top:1px solid var(--border);font-size:11px;color:var(--muted)}

/* ===================== MAIN CONTENT ===================== */
.main{
  margin-left:var(--sidebar-w);flex:1;
  padding:24px 28px;min-height:100vh;
  max-width:calc(100vw - var(--sidebar-w));
}
.page-header{
  margin-bottom:22px;display:flex;
  justify-content:space-between;align-items:flex-start;
  gap:12px;flex-wrap:wrap;
}
.page-header-text h1{font-size:20px;font-weight:700;color:var(--text-bright)}
.page-header-text p{color:var(--muted);font-size:12px;margin-top:3px}

/* ===================== CARDS ===================== */
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:22px}
.card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:18px 16px;
  position:relative;overflow:hidden;
}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.card.green::before{background:var(--green)}
.card.red::before{background:var(--red)}
.card.accent::before{background:var(--accent)}
.card.yellow::before{background:var(--yellow)}
.card-icon{font-size:22px;margin-bottom:10px}
.card-label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;font-weight:600}
.card-value{font-size:22px;font-weight:700;color:var(--text-bright);margin-top:5px;line-height:1.2;word-break:break-word}
.card.green .card-value{color:var(--green)}
.card.red .card-value{color:var(--red)}
.card.accent .card-value{color:var(--accent)}
.card.yellow .card-value{color:var(--yellow)}
.card-sub{font-size:11px;color:var(--muted);margin-top:6px}

/* ===================== TABLE ===================== */
.table-wrap{
  background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);overflow:hidden;margin-bottom:22px;
}
.table-toolbar{
  padding:14px 18px;border-bottom:1px solid var(--border);
  display:flex;justify-content:space-between;align-items:center;
  gap:10px;flex-wrap:wrap;
}
.table-toolbar h3{font-size:14px;font-weight:600;color:var(--text-bright)}
.table-toolbar small{font-size:11px;color:var(--muted)}
.table-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}
table{width:100%;border-collapse:collapse;min-width:520px}
thead th{
  background:var(--surface2);padding:9px 14px;
  text-align:left;font-size:11px;color:var(--muted);
  text-transform:uppercase;letter-spacing:.8px;font-weight:600;white-space:nowrap;
}
tbody td{
  padding:10px 14px;font-size:12px;
  border-bottom:1px solid var(--border);vertical-align:middle;
}
tbody tr:last-child td{border-bottom:none}
tbody tr:hover td{background:var(--surface2)}
.empty-row td{text-align:center;color:var(--muted);padding:32px;font-size:12px}

/* ===================== BADGE ===================== */
.badge{
  display:inline-flex;align-items:center;
  padding:3px 10px;border-radius:20px;
  font-size:11px;font-weight:600;white-space:nowrap;
}
.badge-income{background:var(--green-dim);color:var(--green)}
.badge-expense{background:var(--red-dim);color:var(--red)}
.badge-info{background:var(--accent-dim);color:var(--accent)}

/* ===================== BUTTONS ===================== */
.btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:9px 16px;border-radius:8px;font-size:12px;
  font-weight:600;cursor:pointer;text-decoration:none;
  border:none;transition:all .15s;line-height:1;white-space:nowrap;
}
.btn:active{transform:translateY(1px)}
.btn-primary{background:var(--accent);color:#fff}
.btn-primary:hover{background:#6970f0}
.btn-danger{background:var(--red-dim);color:var(--red);border:1px solid transparent}
.btn-danger:hover{background:rgba(248,81,73,.28)}
.btn-ghost{background:var(--surface2);color:var(--text);border:1px solid var(--border)}
.btn-ghost:hover{background:var(--surface3)}
.btn-sm{padding:5px 12px;font-size:12px}

/* ===================== FORMS ===================== */
.form-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:22px 20px;margin-bottom:22px;
}
.form-card h3{
  font-size:14px;font-weight:600;color:var(--text-bright);
  margin-bottom:18px;padding-bottom:12px;border-bottom:1px solid var(--border);
}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-grid.cols-3{grid-template-columns:1fr 1fr 1fr}
.form-grid.cols-1{grid-template-columns:1fr}
.form-group{display:flex;flex-direction:column;gap:6px}
.form-group.span-2{grid-column:span 2}
label{font-size:12px;color:var(--muted);font-weight:500}
input,select,textarea{
  background:var(--surface2);border:1px solid var(--border);
  border-radius:7px;padding:10px 12px;
  color:var(--text-bright);font-size:14px;width:100%;
  transition:border-color .15s;
  -webkit-appearance:none;
}
input:focus,select:focus,textarea:focus{
  outline:none;border-color:var(--accent);background:var(--surface3);
}
select option{background:var(--surface);color:var(--text-bright)}
textarea{resize:vertical;min-height:80px}
.form-actions{margin-top:18px;display:flex;gap:10px;flex-wrap:wrap}

/* ===================== ALERTS ===================== */
.alert{
  padding:10px 14px;border-radius:8px;font-size:12px;
  margin-bottom:16px;display:flex;align-items:center;gap:8px;
}
.alert-success{background:var(--green-dim);color:var(--green);border:1px solid rgba(63,185,80,.3)}
.alert-error{background:var(--red-dim);color:var(--red);border:1px solid rgba(248,81,73,.3)}

/* ===================== CHARTS ===================== */
.chart-grid{display:grid;grid-template-columns:3fr 2fr;gap:16px;margin-bottom:22px}
.chart-card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:18px;
}
.chart-card h3{font-size:12px;font-weight:600;color:var(--text-bright);margin-bottom:14px}
.chart-card canvas{display:block;max-width:100%}

/* ===================== AMOUNT COLORS ===================== */
.amount-income{color:var(--green);font-weight:600}
.amount-expense{color:var(--red);font-weight:600}

/* ===================== RESPONSIVE MOBILE ===================== */
@media(max-width:768px){
  .topbar{display:flex}
  .sidebar{transform:translateX(-100%)}
  .sidebar.open{transform:translateX(0)}
  .main{
    margin-left:0;
    padding:16px;
    padding-top:calc(var(--topbar-h) + 16px);
    max-width:100vw;
  }
  .chart-grid{grid-template-columns:1fr}
  .form-grid,.form-grid.cols-3{grid-template-columns:1fr}
  .form-group.span-2{grid-column:span 1}
  .cards{grid-template-columns:1fr 1fr}
  .page-header{flex-direction:column;align-items:flex-start}
  .card-value{font-size:18px}
  .table-wrap{border-radius:8px}
  table{min-width:480px}
}
@media(max-width:420px){
  .cards{grid-template-columns:1fr}
}
</style>
</head>
<body>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Mobile Topbar -->
<div class="topbar">
  <button class="hamburger" id="hamburgerBtn" aria-label="Menu">&#9776;</button>
  <div class="topbar-brand">&#128176; <span>QUEENSTAR REPORT</span></div>
</div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="logo">&#128176; <span>QUEENSTAR REPORT</span></div>
    <small>Analytic Dasboard Report</small>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Overview</div>
    <a href="<?= BASE_URL ?>/" class="nav-link <?= $is_dashboard ? 'active' : '' ?>">
      <span class="icon">&#128202;</span> Dashboard
    </a>

    <div class="nav-section">Keuangan</div>
    <a href="<?= BASE_URL ?>/transactions/" class="nav-link <?= $is_transactions ? 'active' : '' ?>">
      <span class="icon">&#128179;</span> Transaksi
    </a>

    <div class="nav-section">Talent</div>
    <a href="<?= BASE_URL ?>/talents/" class="nav-link <?= $is_talents ? 'active' : '' ?>">
      <span class="icon">&#127917;</span> Data Talent
    </a>
    <a href="<?= BASE_URL ?>/talent_logs/" class="nav-link <?= $is_talent_logs ? 'active' : '' ?>">
      <span class="icon">&#128200;</span> Talent Logs
    </a>

    <div class="nav-section">Pengaturan</div>
    <a href="<?= BASE_URL ?>/settings.php" class="nav-link <?= $is_settings ? 'active' : '' ?>">
      <span class="icon">&#9881;&#65039;</span> Settings
    </a>
  </nav>
  <div class="sidebar-footer">
    &#128336; <?= date('d M Y H:i') ?> WIB
  </div>
</aside>

<!-- Main Content -->
<main class="main">
