<?php
// transactions/edit.php — Edit Transaksi
require_once '../config.php';

$pageTitle = 'Edit Transaksi — Finance HQ';
$errors    = [];

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . '/transactions/');
    exit;
}

$conn = db_connect();

// Ambil data transaksi
$st = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
if (!$st) {
    $conn->close();
    header('Location: ' . BASE_URL . '/transactions/');
    exit;
}
$st->bind_param('i', $id);
$st->execute();
$tx = $st->get_result()->fetch_assoc();
$st->close();

if (!$tx) {
    $conn->close();
    header('Location: ' . BASE_URL . '/transactions/?notfound=1');
    exit;
}

$form = [
    'type'     => $tx['type'],
    'category' => $tx['category'],
    'amount'   => (string)$tx['amount'],
    'note'     => $tx['note'] ?? '',
    'date'     => $tx['date'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $type     = $_POST['type']     ?? '';
    $category = trim($_POST['category'] ?? '');
    $amount   = $_POST['amount']   ?? '';
    $note     = trim($_POST['note'] ?? '');
    $date     = trim($_POST['date'] ?? '');

    $form = compact('type', 'category', 'amount', 'note', 'date');

    // Validasi
    if (!in_array($type, ['income', 'expense'], true)) {
        $errors[] = 'Tipe transaksi tidak valid.';
    }

    $valid_cats = $type === 'income' ? CATEGORIES_INCOME : CATEGORIES_EXPENSE;
    if ($category === '' || !in_array($category, $valid_cats, true)) {
        $errors[] = 'Pilih kategori yang valid.';
    }

    if (!ctype_digit((string)$amount) || (int)$amount <= 0) {
        $errors[] = 'Jumlah harus berupa angka bulat lebih dari 0.';
    }
    if (strlen($note) > 500) {
        $errors[] = 'Keterangan terlalu panjang (maks 500 karakter).';
    }
    $date_obj = DateTime::createFromFormat('Y-m-d', $date);
    if (!$date_obj || $date_obj->format('Y-m-d') !== $date) {
        $errors[] = 'Format tanggal tidak valid.';
    }

    if (empty($errors)) {
        $amt_int = (int)$amount;
        $stmt    = $conn->prepare(
            "UPDATE transactions SET type=?, category=?, amount=?, note=?, date=? WHERE id=?"
        );
        if (!$stmt) {
            $errors[] = 'DB prepare error.';
        } else {
            $stmt->bind_param('ssissi', $type, $category, $amt_int, $note, $date, $id);
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                header('Location: ' . BASE_URL . '/transactions/?edited=1');
                exit;
            } else {
                $errors[] = 'Gagal menyimpan perubahan.';
                error_log('transactions/edit DB error: ' . $stmt->error);
                $stmt->close();
            }
        }
    }
}
$conn->close();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>✏️ Edit Transaksi</h1>
    <p>ID #<?= $id ?> — <?= e(date('d M Y', strtotime($tx['date']))) ?></p>
  </div>
  <a href="<?= BASE_URL ?>/transactions/" class="btn btn-ghost">← Kembali</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">⚠️ <?= implode(' | ', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="form-card">
  <h3>Form Edit Transaksi</h3>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-grid">

      <!-- Tipe -->
      <div class="form-group">
        <label for="type">Tipe Transaksi *</label>
        <select name="type" id="type" required onchange="updateCategories()">
          <option value="income"  <?= $form['type']==='income'  ? 'selected' : '' ?>>↑ Income (Pemasukan)</option>
          <option value="expense" <?= $form['type']==='expense' ? 'selected' : '' ?>>↓ Expense (Pengeluaran)</option>
        </select>
      </div>

      <!-- Kategori -->
      <div class="form-group">
        <label for="category">Kategori *</label>
        <select name="category" id="category" required>
          <option value="">-- Pilih Kategori --</option>
        </select>
      </div>

      <!-- Jumlah -->
      <div class="form-group">
        <label for="amount">Jumlah (Rp) *</label>
        <input type="number" name="amount" id="amount"
               value="<?= e($form['amount']) ?>"
               min="1" step="1" required>
      </div>

      <!-- Tanggal -->
      <div class="form-group">
        <label for="date">Tanggal *</label>
        <input type="date" name="date" id="date"
               value="<?= e($form['date']) ?>" required>
      </div>

      <!-- Keterangan -->
      <div class="form-group span-2">
        <label for="note">Keterangan (Opsional)</label>
        <textarea name="note" id="note" maxlength="500"><?= e($form['note']) ?></textarea>
      </div>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
      <a href="<?= BASE_URL ?>/transactions/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<script>
var cats = {
  income:  <?= json_encode(CATEGORIES_INCOME)  ?>,
  expense: <?= json_encode(CATEGORIES_EXPENSE) ?>
};
var savedCat = <?= json_encode($form['category']) ?>;

function updateCategories() {
  var type = document.getElementById('type').value;
  var sel  = document.getElementById('category');
  sel.innerHTML = '<option value="">-- Pilih Kategori --</option>';
  (cats[type] || []).forEach(function(c) {
    var opt       = document.createElement('option');
    opt.value     = c;
    opt.textContent = c;
    if (c === savedCat) opt.selected = true;
    sel.appendChild(opt);
  });
}
updateCategories();
</script>

<?php require_once '../footer.php'; ?>
