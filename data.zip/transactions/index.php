<?php
// transactions/index.php — Daftar Transaksi
require_once '../config.php';

$pageTitle = 'Transaksi — Finance HQ';
$conn      = db_connect();
$msg       = '';
$msg_type  = '';

// ── Handle DELETE ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_verify();
    $del_id = (int)($_POST['id'] ?? 0);
    if ($del_id > 0) {
        $st = $conn->prepare("DELETE FROM transactions WHERE id = ?");
        if ($st) {
            $st->bind_param('i', $del_id);
            if ($st->execute() && $st->affected_rows > 0) {
                $msg = 'Transaksi berhasil dihapus.'; $msg_type = 'success';
            } else {
                $msg = 'Gagal menghapus atau transaksi tidak ditemukan.'; $msg_type = 'error';
            }
            $st->close();
        } else {
            $msg = 'DB error.'; $msg_type = 'error';
        }
    }
}

// ── Filter ────────────────────────────────────────────────
$allowed_types = ['income', 'expense', ''];
$filter_type   = in_array($_GET['type'] ?? '', $allowed_types, true) ? ($_GET['type'] ?? '') : '';

$filter_month = '';
if (!empty($_GET['month']) && preg_match('/^\d{4}-\d{2}$/', $_GET['month'])) {
    $filter_month = $_GET['month'];
}

// ── Build Query ───────────────────────────────────────────
$where  = [];
$params = [];
$types  = '';

if ($filter_type !== '') {
    $where[]  = "type = ?";
    $params[] = $filter_type;
    $types   .= 's';
}
if ($filter_month !== '') {
    $where[]  = "DATE_FORMAT(date,'%Y-%m') = ?";
    $params[] = $filter_month;
    $types   .= 's';
}

$sql = "SELECT id, type, category, amount, note, date, created_at
        FROM transactions";
if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY date DESC, created_at DESC LIMIT 200";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    $conn->close();
    die('DB prepare error: ' . htmlspecialchars($conn->error));
}
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$transactions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ── Summary ───────────────────────────────────────────────
$sum_sql    = "SELECT
    COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS inc,
    COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS exp,
    COUNT(*) AS total
  FROM transactions";
$sum_where  = [];
$sum_params = [];
$sum_types  = '';

if ($filter_type !== '') {
    $sum_where[]  = "type = ?";
    $sum_params[] = $filter_type;
    $sum_types   .= 's';
}
if ($filter_month !== '') {
    $sum_where[]  = "DATE_FORMAT(date,'%Y-%m') = ?";
    $sum_params[] = $filter_month;
    $sum_types   .= 's';
}
if ($sum_where) {
    $sum_sql .= " WHERE " . implode(' AND ', $sum_where);
}

$st_sum = $conn->prepare($sum_sql);
if ($st_sum) {
    if ($sum_params) {
        $st_sum->bind_param($sum_types, ...$sum_params);
    }
    $st_sum->execute();
    $sum = $st_sum->get_result()->fetch_assoc();
    $st_sum->close();
} else {
    $sum = ['inc' => 0, 'exp' => 0, 'total' => 0];
}

// ── Generate one-time export token ────────────────────────
session_start_once();
$export_token = bin2hex(random_bytes(16));
$_SESSION['export_token'] = $export_token;

$conn->close();

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>💳 Transaksi</h1>
    <p>Riwayat pemasukan &amp; pengeluaran</p>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a href="export.php?export_token=<?= urlencode($export_token) ?><?= $filter_type ? '&type=' . urlencode($filter_type) : '' ?><?= $filter_month ? '&month=' . urlencode($filter_month) : '' ?>"
       class="btn btn-ghost">⬇️ Export CSV</a>
    <a href="add.php" class="btn btn-primary">＋ Tambah</a>
  </div>
</div>

<?php if ($msg): ?>
  <div class="alert alert-<?= e($msg_type) ?>"><?= e($msg) ?></div>
<?php endif; ?>
<?php if (($_GET['added'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Transaksi berhasil ditambahkan.</div>
<?php endif; ?>
<?php if (($_GET['edited'] ?? '') === '1'): ?>
  <div class="alert alert-success">✅ Transaksi berhasil diubah.</div>
<?php endif; ?>

<!-- Summary Cards -->
<div class="cards">
  <div class="card green">
    <div class="card-label">Total Pemasukan</div>
    <div class="card-value"><?= rupiah((float)$sum['inc']) ?></div>
    <div class="card-sub"><?= (int)$sum['total'] ?> transaksi ditampilkan</div>
  </div>
  <div class="card red">
    <div class="card-label">Total Pengeluaran</div>
    <div class="card-value"><?= rupiah((float)$sum['exp']) ?></div>
  </div>
  <div class="card accent">
    <div class="card-label">Selisih</div>
    <?php $diff = (float)$sum['inc'] - (float)$sum['exp']; ?>
    <div class="card-value" style="color:<?= $diff >= 0 ? 'var(--green)' : 'var(--red)' ?>">
      <?= ($diff < 0 ? '−' : '') . rupiah(abs($diff)) ?>
    </div>
  </div>
</div>

<!-- Filter -->
<div style="margin-bottom:16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
  <label style="color:var(--muted);font-size:13px">Tipe:</label>
  <a href="?<?= $filter_month ? 'month=' . urlencode($filter_month) : '' ?>"
     class="btn btn-sm <?= $filter_type==='' ? 'btn-primary' : 'btn-ghost' ?>">Semua</a>
  <a href="?type=income<?= $filter_month ? '&month=' . urlencode($filter_month) : '' ?>"
     class="btn btn-sm <?= $filter_type==='income' ? 'btn-primary' : 'btn-ghost' ?>">↑ Income</a>
  <a href="?type=expense<?= $filter_month ? '&month=' . urlencode($filter_month) : '' ?>"
     class="btn btn-sm <?= $filter_type==='expense' ? 'btn-primary' : 'btn-ghost' ?>">↓ Expense</a>

  <label style="color:var(--muted);font-size:13px;margin-left:8px">Bulan:</label>
  <input type="month"
         style="background:var(--surface2);border:1px solid var(--border);border-radius:7px;
                padding:5px 10px;color:var(--text-bright);font-size:12px"
         value="<?= e($filter_month) ?>"
         onchange="location.href='?<?= $filter_type ? 'type=' . urlencode($filter_type) . '&' : '' ?>month='+this.value">
  <?php if ($filter_month): ?>
    <a href="?<?= $filter_type ? 'type=' . urlencode($filter_type) : '' ?>"
       class="btn btn-sm btn-ghost">✕ Reset</a>
  <?php endif; ?>
</div>

<div class="table-wrap">
  <div class="table-toolbar">
    <h3>Riwayat Transaksi</h3>
    <small><?= count($transactions) ?> entri</small>
  </div>
  <div class="table-scroll">
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Tanggal</th>
        <th>Tipe</th>
        <th>Kategori</th>
        <th>Jumlah</th>
        <th>Keterangan</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($transactions)): ?>
      <tr class="empty-row"><td colspan="7">📭 Belum ada transaksi</td></tr>
    <?php else: ?>
      <?php foreach ($transactions as $i => $tx): ?>
      <tr>
        <td style="color:var(--muted)"><?= $i + 1 ?></td>
        <td><?= e(date('d M Y', strtotime($tx['date']))) ?></td>
        <td>
          <span class="badge badge-<?= $tx['type'] === 'income' ? 'income' : 'expense' ?>">
            <?= $tx['type'] === 'income' ? '↑ Income' : '↓ Expense' ?>
          </span>
        </td>
        <td><?= e($tx['category']) ?></td>
        <td class="amount-<?= $tx['type'] ?>"><?= rupiah((float)$tx['amount']) ?></td>
        <td style="color:var(--muted);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
          <?= $tx['note'] ? e($tx['note']) : '—' ?>
        </td>
        <td>
          <div style="display:flex;gap:5px">
            <a href="edit.php?id=<?= (int)$tx['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
            <form method="post" onsubmit="return confirm('Hapus transaksi ini?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$tx['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<?php require_once '../footer.php'; ?>
