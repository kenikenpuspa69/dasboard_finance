<?php
// transactions/add.php — Tambah Transaksi
require_once '../config.php';

$pageTitle = 'Tambah Transaksi — Finance HQ';
$errors    = [];
$form = [
    'type'     => 'income',
    'category' => '',
    'amount'   => '',
    'note'     => '',
    'date'     => date('Y-m-d'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $type     = $_POST['type']     ?? '';
    $category = trim($_POST['category'] ?? '');
    $amount   = $_POST['amount']   ?? '';
    $note     = trim($_POST['note'] ?? '');
    $date     = trim($_POST['date'] ?? '');

    $form = compact('type', 'category', 'amount', 'note', 'date');

    // Validasi type
    if (!in_array($type, ['income', 'expense'], true)) {
        $errors[] = 'Tipe transaksi tidak valid.';
    }

    // Validasi kategori — harus dari daftar yang valid sesuai type
    // FIX: CATEGORIES_INCOME / CATEGORIES_EXPENSE sudah didefinisikan di config.php
    if ($type === 'income') {
        $valid_cats = CATEGORIES_INCOME;
    } elseif ($type === 'expense') {
        $valid_cats = CATEGORIES_EXPENSE;
    } else {
        $valid_cats = [];
    }

    if ($category === '' || !in_array($category, $valid_cats, true)) {
        $errors[] = 'Pilih kategori yang valid.';
    }

    if (!ctype_digit((string)$amount) || (int)$amount <= 0) {
        $errors[] = 'Jumlah harus berupa angka bulat lebih dari 0.';
    }
    if (strlen($note) > 500) {
        $errors[] = 'Keterangan terlalu panjang (maks 500 karakter).';
    }
    $date_obj = DateTime::createFromFormat('Y-m-d', $date);
    if (!$date_obj || $date_obj->format('Y-m-d') !== $date) {
        $errors[] = 'Format tanggal tidak valid.';
    }

    if (empty($errors)) {
        $conn = db_connect();
        $stmt = $conn->prepare(
            "INSERT INTO transactions (type, category, amount, note, date) VALUES (?, ?, ?, ?, ?)"
        );
        if (!$stmt) {
            $errors[] = 'DB prepare error.';
        } else {
            $amt_int = (int)$amount;
            $stmt->bind_param('ssiss', $type, $category, $amt_int, $note, $date);
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                header('Location: ' . BASE_URL . '/transactions/?added=1');
                exit;
            } else {
                $errors[] = 'Gagal menyimpan ke database.';
                error_log('transactions/add DB error: ' . $stmt->error);
                $stmt->close();
            }
            $conn->close();
        }
    }
}

require_once '../header.php';
?>

<div class="page-header">
  <div class="page-header-text">
    <h1>＋ Tambah Transaksi</h1>
    <p>Input pemasukan atau pengeluaran baru</p>
  </div>
  <a href="<?= BASE_URL ?>/transactions/" class="btn btn-ghost">← Kembali</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error">⚠️ <?= implode(' | ', array_map('e', $errors)) ?></div>
<?php endif; ?>

<div class="form-card">
  <h3>Form Transaksi</h3>
  <form method="post" autocomplete="off" id="txForm">
    <?= csrf_field() ?>
    <div class="form-grid">

      <!-- Tipe -->
      <div class="form-group">
        <label for="type">Tipe Transaksi *</label>
        <select name="type" id="type" required onchange="updateCategories()">
          <option value="income"  <?= $form['type']==='income'  ? 'selected' : '' ?>>↑ Income (Pemasukan)</option>
          <option value="expense" <?= $form['type']==='expense' ? 'selected' : '' ?>>↓ Expense (Pengeluaran)</option>
        </select>
      </div>

      <!-- Kategori (dinamis via JS) -->
      <div class="form-group">
        <label for="category">Kategori *</label>
        <select name="category" id="category" required>
          <option value="">-- Pilih Kategori --</option>
        </select>
      </div>

      <!-- Jumlah -->
      <div class="form-group">
        <label for="amount">Jumlah (Rp) *</label>
        <input type="number" name="amount" id="amount"
               placeholder="cth: 500000"
               value="<?= e((string)$form['amount']) ?>"
               min="1" step="1" required>
      </div>

      <!-- Tanggal -->
      <div class="form-group">
        <label for="date">Tanggal *</label>
        <input type="date" name="date" id="date"
               value="<?= e($form['date']) ?>" required>
      </div>

      <!-- Keterangan -->
      <div class="form-group span-2">
        <label for="note">Keterangan (Opsional)</label>
        <textarea name="note" id="note"
                  placeholder="cth: Topup member April 2026"
                  maxlength="500"><?= e($form['note']) ?></textarea>
      </div>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary">💾 Simpan Transaksi</button>
      <a href="<?= BASE_URL ?>/transactions/" class="btn btn-ghost">Batal</a>
    </div>
  </form>
</div>

<!-- Quick Reference -->
<div class="form-card">
  <h3>💡 Panduan Kategori</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px">
    <div>
      <div style="color:var(--green);font-weight:600;margin-bottom:6px">↑ Income</div>
      <div style="color:var(--muted)"><?= implode(' · ', array_map('e', CATEGORIES_INCOME)) ?></div>
    </div>
    <div>
      <div style="color:var(--red);font-weight:600;margin-bottom:6px">↓ Expense</div>
      <div style="color:var(--muted)"><?= implode(' · ', array_map('e', CATEGORIES_EXPENSE)) ?></div>
    </div>
  </div>
</div>

<script>
// Kategori dari PHP (sudah di-define di config.php)
var cats = {
  income:  <?= json_encode(CATEGORIES_INCOME)  ?>,
  expense: <?= json_encode(CATEGORIES_EXPENSE) ?>
};
var savedCat = <?= json_encode($form['category']) ?>;

function updateCategories() {
  var type = document.getElementById('type').value;
  var sel  = document.getElementById('category');
  sel.innerHTML = '<option value="">-- Pilih Kategori --</option>';
  (cats[type] || []).forEach(function(c) {
    var opt       = document.createElement('option');
    opt.value     = c;
    opt.textContent = c;
    if (c === savedCat) opt.selected = true;
    sel.appendChild(opt);
  });
}
updateCategories();
</script>

<?php require_once '../footer.php'; ?>
