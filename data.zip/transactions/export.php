<?php
// transactions/export.php — Export ke CSV
// FIX: proteksi akses via CSRF/session — hanya bisa diakses dari dalam aplikasi
require_once '../config.php';

// Verifikasi: harus ada session aktif (user sudah mengakses dashboard)
// Export hanya bisa diakses dari link di dalam aplikasi, bukan URL langsung
session_start_once();

// Cek token export — dibuat saat link export di-render di transactions/index.php
$token        = $_GET['export_token'] ?? '';
$stored_token = $_SESSION['export_token'] ?? '';

if (
    empty($token) ||
    empty($stored_token) ||
    !hash_equals($stored_token, $token)
) {
    http_response_code(403);
    die('Akses ditolak. Gunakan tombol Export di halaman Transaksi.');
}

// Hapus token setelah digunakan (one-time use)
unset($_SESSION['export_token']);

// Filter opsional
$allowed_types = ['income', 'expense', ''];
$filter_type   = in_array($_GET['type'] ?? '', $allowed_types, true) ? ($_GET['type'] ?? '') : '';

$conn = db_connect();

if ($filter_type !== '') {
    $stmt = $conn->prepare(
        "SELECT id, type, category, amount, note, date, created_at
         FROM transactions WHERE type = ?
         ORDER BY date DESC, created_at DESC"
    );
    if (!$stmt) { $conn->close(); die('DB error.'); }
    $stmt->bind_param('s', $filter_type);
} else {
    $stmt = $conn->prepare(
        "SELECT id, type, category, amount, note, date, created_at
         FROM transactions ORDER BY date DESC, created_at DESC"
    );
    if (!$stmt) { $conn->close(); die('DB error.'); }
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();

$filename = 'transaksi_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Cache-Control: no-store, no-cache');

// BOM untuk Excel agar UTF-8 terbaca benar
echo "\xEF\xBB\xBF";

$out = fopen('php://output', 'w');
fputcsv($out, ['ID', 'Tipe', 'Kategori', 'Jumlah (Rp)', 'Keterangan', 'Tanggal', 'Dibuat']);

foreach ($rows as $row) {
    fputcsv($out, [
        $row['id'],
        $row['type'],
        $row['category'],
        $row['amount'],
        $row['note'] ?? '',
        $row['date'],
        $row['created_at'],
    ]);
}
fclose($out);
exit;
