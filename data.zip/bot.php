<?php
// bot.php — Telegram Bot Webhook Handler
// Inline Keyboard + Step Flow (session via state file)
// Setup: https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://media69digitalstore.my.id/dashboard_analytic/bot.php

require_once __DIR__ . '/config.php';

// ============================================================
// Ambil & validasi data dari Telegram
// ============================================================
$input  = file_get_contents('php://input');
$update = json_decode($input, true);

if (empty($update)) {
    http_response_code(200);
    exit;
}

// Bisa dari message atau callback_query
$is_callback = !empty($update['callback_query']);

if ($is_callback) {
    $callback    = $update['callback_query'];
    $chat_id     = (int)$callback['message']['chat']['id'];
    $user_id     = (int)$callback['from']['id'];
    $callback_id = $callback['id'];
    $data        = $callback['data'] ?? '';
    $msg_id      = (int)$callback['message']['message_id'];
} elseif (!empty($update['message']) && isset($update['message']['text'])) {
    $message = $update['message'];
    $chat_id = (int)$message['chat']['id'];
    $user_id = (int)$message['from']['id'];
    $text    = trim((string)$message['text']);
} else {
    http_response_code(200);
    exit;
}

// ── Security: hanya ALLOWED_USER_ID ──────────────────────
if ($user_id !== ALLOWED_USER_ID) {
    tgReply($chat_id, '⛔ Akses ditolak. Bot ini hanya untuk pemilik.');
    exit;
}

// ============================================================
// State Management (per-user JSON file)
// ============================================================
$state_file = __DIR__ . '/data/bot_state_' . $user_id . '.json';

function stateLoad(int $user_id): array {
    global $state_file;
    if (!file_exists($state_file)) return [];
    $d = json_decode(file_get_contents($state_file), true);
    return is_array($d) ? $d : [];
}

function stateSave(array $state): void {
    global $state_file;
    $dir = dirname($state_file);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    file_put_contents($state_file, json_encode($state, JSON_UNESCAPED_UNICODE));
}

function stateClear(): void {
    global $state_file;
    if (file_exists($state_file)) unlink($state_file);
}

// ============================================================
// Handle Callback Query (tombol inline keyboard)
// ============================================================
if ($is_callback) {
    // Acknowledge callback agar loading spinner hilang
    tgAnswerCallback($callback_id);

    $state = stateLoad($user_id);

    // ── Menu utama dari callback ──
    if ($data === 'menu') {
        stateClear();
        tgEditOrNew($chat_id, $msg_id, msgMenuText(), menuKeyboard());
        exit;
    }

    // ── Saldo & Report langsung ──
    if ($data === 'saldo') {
        stateClear();
        tgEditOrNew($chat_id, $msg_id, cmdSaldo(), backKeyboard());
        exit;
    }
    if ($data === 'report') {
        stateClear();
        tgEditOrNew($chat_id, $msg_id, cmdReport(), backKeyboard());
        exit;
    }
    if ($data === 'listalent') {
        stateClear();
        tgEditOrNew($chat_id, $msg_id, cmdListTalent(), backKeyboard());
        exit;
    }

    // ── Step: Pilih tipe transaksi ──
    if ($data === 'add_income') {
        $state = ['step' => 'pick_category', 'type' => 'income'];
        stateSave($state);
        tgEditOrNew($chat_id, $msg_id,
            "💰 <b>Pemasukan</b>\n\nPilih kategori:",
            categoryKeyboard('income')
        );
        exit;
    }
    if ($data === 'add_expense') {
        $state = ['step' => 'pick_category', 'type' => 'expense'];
        stateSave($state);
        tgEditOrNew($chat_id, $msg_id,
            "💸 <b>Pengeluaran</b>\n\nPilih kategori:",
            categoryKeyboard('expense')
        );
        exit;
    }

    // ── Step: Pilih kategori transaksi ──
    if (str_starts_with($data, 'cat_') && isset($state['step']) && $state['step'] === 'pick_category') {
        $category = urldecode(substr($data, 4));
        $state['step']     = 'enter_amount';
        $state['category'] = $category;
        stateSave($state);
        $emoji = $state['type'] === 'income' ? '💰' : '💸';
        tgEditOrNew($chat_id, $msg_id,
            "$emoji <b>" . tgE(strtoupper($state['type'])) . "</b>\n" .
            "📂 Kategori: <b>" . tgE($category) . "</b>\n\n" .
            "Ketik nominal (angka saja, contoh: <code>500000</code>):",
            cancelKeyboard()
        );
        exit;
    }

    // ── Step: Log Talent — pilih talent ──
    if ($data === 'log_talent') {
        $state = ['step' => 'log_pick_talent'];
        stateSave($state);
        tgEditOrNew($chat_id, $msg_id,
            "🎭 <b>Log Performa Talent</b>\n\nPilih talent:",
            talentKeyboard()
        );
        exit;
    }

    // ── Step: Log Talent — setelah pilih talent ──
    if (str_starts_with($data, 'talent_') && isset($state['step']) && $state['step'] === 'log_pick_talent') {
        $talent_id = (int)substr($data, 7);
        // Ambil nama talent
        $conn = db_connect();
        $st   = $conn->prepare("SELECT name FROM talents WHERE id = ?");
        $st->bind_param('i', $talent_id);
        $st->execute();
        $tn = $st->get_result()->fetch_assoc();
        $st->close();
        $conn->close();

        if (!$tn) {
            tgEditOrNew($chat_id, $msg_id, "⚠️ Talent tidak ditemukan.", backKeyboard());
            exit;
        }

        $state = ['step' => 'log_pick_kategori', 'talent_id' => $talent_id, 'talent_name' => $tn['name']];
        stateSave($state);
        tgEditOrNew($chat_id, $msg_id,
            "🎭 Talent: <b>" . tgE($tn['name']) . "</b>\n\nPilih kategori perform:",
            kategorPerformKeyboard()
        );
        exit;
    }

    // ── Step: Log — pilih kategori perform ──
    if (str_starts_with($data, 'kp_') && isset($state['step']) && $state['step'] === 'log_pick_kategori') {
        $kat = substr($data, 3); // Solo atau Duet
        $state['step']    = 'log_enter_followers';
        $state['perform'] = $kat; // simpan ke field 'perform' (DB lama)
        stateSave($state);
        tgEditOrNew($chat_id, $msg_id,
            "🎭 <b>" . tgE($state['talent_name']) . "</b> — " . tgE($kat) . "\n\n" .
            "Ketik <b>Followers Baru</b> (angka, contoh: <code>250</code>):",
            cancelKeyboard()
        );
        exit;
    }

    // ── Confirm Log Talent ──
    if ($data === 'confirm_log' && isset($state['step']) && $state['step'] === 'log_confirm') {
        $talent_id      = (int)$state['talent_id'];
        $talent_name    = $state['talent_name'];
        $perform        = $state['perform'];        // Solo / Duet → kolom perform
        $followers_baru = (int)$state['followers_baru']; // → kolom rating
        $views          = (int)$state['views'];
        $income_val     = (int)$state['income'];
        $room           = $state['room'];           // → kolom duration
        $log_date       = date('Y-m-d');

        $conn = db_connect();
        $stmt = $conn->prepare(
            "INSERT INTO talent_logs (talent_id, perform, views, income, rating, duration, log_date)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        if (!$stmt) {
            $conn->close();
            stateClear();
            tgEditOrNew($chat_id, $msg_id, "❌ DB prepare error.", backKeyboard());
            exit;
        }
        $f_float = (float)$followers_baru;
        $stmt->bind_param('isiidss', $talent_id, $perform, $views, $income_val, $f_float, $room, $log_date);

        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close(); $conn->close();
            error_log("Bot confirm_log DB error: $err");
            stateClear();
            tgEditOrNew($chat_id, $msg_id, "❌ Gagal menyimpan log.", backKeyboard());
            exit;
        }
        $log_id = (int)$conn->insert_id;
        $stmt->close(); $conn->close();

        stateClear();
        tgEditOrNew($chat_id, $msg_id,
            "✅ <b>Log Performa Tersimpan!</b>\n\n" .
            "🎭 Talent         : <b>" . tgE($talent_name) . "</b>\n" .
            "🎤 Kategori       : " . tgE($perform) . "\n" .
            "👥 Followers Baru : " . number_format($followers_baru) . "\n" .
            "👁 Views          : " . number_format($views) . "\n" .
            "💰 Income         : <b>Rp " . number_format($income_val, 0, ',', '.') . "</b>\n" .
            ($room !== '' ? "🏠 Room           : " . tgE($room) . "\n" : '') .
            "📅 Tanggal        : " . tgE($log_date) . "\n" .
            "🆔 Log ID         : #$log_id",
            menuKeyboard()
        );
        exit;
    }

    // ── Cancel / Batal ──
    if ($data === 'cancel') {
        stateClear();
        tgEditOrNew($chat_id, $msg_id, "❌ Dibatalkan.\n\n" . msgMenuText(), menuKeyboard());
        exit;
    }

    // Fallback
    http_response_code(200);
    exit;
}

// ============================================================
// Handle Message (teks biasa & command)
// ============================================================
if (isset($text)) {
    // Jika ada state aktif, proses sebagai input step
    $state = stateLoad($user_id);

    if (!empty($state['step'])) {
        handleStepInput($chat_id, $text, $state);
        exit;
    }

    // ── Parse command ─────────────────────────────────────────
    $parts   = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
    $command = strtolower($parts[0] ?? '');
    if (str_contains($command, '@')) {
        $command = explode('@', $command)[0];
    }

    // ── Router ────────────────────────────────────────────────
    switch ($command) {
        case '/start':
        case '/menu':
        case '/help':
            stateClear();
            tgReplyInline($chat_id, msgMenuText(), menuKeyboard());
            break;

        // Command teks tetap bisa digunakan (legacy)
        case '/add':
            tgReply($chat_id, cmdAdd($parts));
            break;
        case '/log':
            tgReply($chat_id, cmdLog($parts));
            break;
        case '/saldo':
            tgReplyInline($chat_id, cmdSaldo(), backKeyboard());
            break;
        case '/report':
            tgReplyInline($chat_id, cmdReport(), backKeyboard());
            break;
        case '/listalent':
            tgReplyInline($chat_id, cmdListTalent(), backKeyboard());
            break;
        default:
            tgReplyInline($chat_id, "❓ Command tidak dikenal.\n\n" . msgMenuText(), menuKeyboard());
    }
}

http_response_code(200);
exit;

// ============================================================
// Step Input Handler
// ============================================================
function handleStepInput(int $chat_id, string $text, array $state): void {
    $step = $state['step'];

    // ── Transaksi: input nominal ──────────────────────────────
    if ($step === 'enter_amount') {
        $amount = preg_replace('/\D/', '', $text); // strip non-digit
        if ($amount === '' || (int)$amount <= 0) {
            tgReply($chat_id,
                "⚠️ Nominal tidak valid.\n\n" .
                "Ketik angka saja, contoh: <code>500000</code>\n" .
                "Atau ketik /batal untuk membatalkan."
            );
            return;
        }

        $type     = $state['type'];
        $category = $state['category'];
        $amt      = (int)$amount;
        $date     = date('Y-m-d');

        $conn = db_connect();
        $stmt = $conn->prepare(
            "INSERT INTO transactions (type, category, amount, note, date) VALUES (?, ?, ?, ?, ?)"
        );
        if (!$stmt) {
            $conn->close();
            stateClear();
            tgReply($chat_id, "❌ DB prepare error.");
            return;
        }
        $note = '';
        $stmt->bind_param('ssiss', $type, $category, $amt, $note, $date);

        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            $conn->close();
            error_log("Bot step cmdAdd DB error: $err");
            stateClear();
            tgReply($chat_id, "❌ Gagal menyimpan transaksi.");
            return;
        }
        $id = (int)$conn->insert_id;
        $stmt->close();
        $conn->close();

        stateClear();
        $emoji = $type === 'income' ? '💰' : '💸';
        tgReplyInline($chat_id,
            "✅ <b>Transaksi Tersimpan!</b>\n\n" .
            "$emoji Tipe      : <b>" . tgE(strtoupper($type)) . "</b>\n" .
            "📂 Kategori : " . tgE($category) . "\n" .
            "💵 Jumlah   : <b>Rp " . number_format($amt, 0, ',', '.') . "</b>\n" .
            "📅 Tanggal  : " . tgE($date) . "\n" .
            "🆔 ID       : #$id",
            menuKeyboard()
        );
        return;
    }

    // ── Log Talent: input followers baru ─────────────────────
    if ($step === 'log_enter_followers') {
        $val = preg_replace('/\D/', '', $text);
        if ($val === '' || (int)$val < 0) {
            tgReply($chat_id, "⚠️ Masukkan angka ≥ 0, contoh: <code>250</code>");
            return;
        }
        $state['followers_baru'] = (int)$val; // akan disimpan ke kolom 'rating'
        $state['step']           = 'log_enter_views';
        stateSave($state);
        tgReply($chat_id,
            "👥 Followers Baru: <b>" . number_format((int)$val) . "</b>\n\n" .
            "Ketik <b>Views</b> (angka, contoh: <code>1500</code>):"
        );
        return;
    }

    // ── Log Talent: input views ───────────────────────────────
    if ($step === 'log_enter_views') {
        $val = preg_replace('/\D/', '', $text);
        if ($val === '' || (int)$val < 0) {
            tgReply($chat_id, "⚠️ Masukkan angka ≥ 0, contoh: <code>1500</code>");
            return;
        }
        $state['views'] = (int)$val;
        $state['step']  = 'log_enter_income';
        stateSave($state);
        tgReply($chat_id,
            "👁 Views: <b>" . number_format((int)$val) . "</b>\n\n" .
            "Ketik <b>Income</b> dari sesi ini (Rp, contoh: <code>200000</code>):"
        );
        return;
    }

    // ── Log Talent: input income ──────────────────────────────
    if ($step === 'log_enter_income') {
        $val = preg_replace('/\D/', '', $text);
        if ($val === '' || (int)$val < 0) {
            tgReply($chat_id, "⚠️ Masukkan angka ≥ 0, contoh: <code>200000</code>");
            return;
        }
        $state['income'] = (int)$val;
        $state['step']   = 'log_enter_room';
        stateSave($state);
        tgReply($chat_id,
            "💰 Income: <b>Rp " . number_format((int)$val, 0, ',', '.') . "</b>\n\n" .
            "Ketik <b>nama Room</b> (atau ketik <code>-</code> jika kosong):"
        );
        return;
    }

    // ── Log Talent: input room ────────────────────────────────
    if ($step === 'log_enter_room') {
        $room = ($text === '-') ? '' : substr(strip_tags(trim($text)), 0, 50);
        // room disimpan ke kolom 'duration' (DB lama)
        $state['room'] = $room;
        $state['step'] = 'log_confirm';
        stateSave($state);

        // Preview & konfirmasi
        $preview =
            "📋 <b>Konfirmasi Log Performa</b>\n\n" .
            "🎭 Talent       : <b>" . tgE($state['talent_name']) . "</b>\n" .
            "🎤 Kategori     : " . tgE($state['perform']) . "\n" .
            "👥 Followers    : " . number_format($state['followers_baru']) . "\n" .
            "👁 Views        : " . number_format($state['views']) . "\n" .
            "💰 Income       : <b>Rp " . number_format($state['income'], 0, ',', '.') . "</b>\n" .
            "🏠 Room         : " . ($room !== '' ? tgE($room) : '—') . "\n" .
            "📅 Tanggal      : " . date('d M Y') . "\n\n" .
            "Simpan log ini?";

        tgReplyInline($chat_id, $preview, confirmLogKeyboard());
        return;
    }

    // Fallback — state tidak dikenal, reset
    stateClear();
    tgReplyInline($chat_id, "⚠️ Sesi tidak dikenal, kembali ke menu.", menuKeyboard());
}

// ============================================================
// Inline Keyboard Definitions
// ============================================================

function menuKeyboard(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '💰 Pemasukan',  'callback_data' => 'add_income'],
                ['text' => '💸 Pengeluaran', 'callback_data' => 'add_expense'],
            ],
            [
                ['text' => '📊 Saldo',   'callback_data' => 'saldo'],
                ['text' => '📋 Report',  'callback_data' => 'report'],
            ],
            [
                ['text' => '🎭 Log Talent', 'callback_data' => 'log_talent'],
                ['text' => '📜 List Talent','callback_data' => 'listalent'],
            ],
        ]
    ];
}

function categoryKeyboard(string $type): array {
    $cats = $type === 'income' ? CATEGORIES_INCOME : CATEGORIES_EXPENSE;
    $rows = [];
    foreach ($cats as $cat) {
        $rows[] = [['text' => $cat, 'callback_data' => 'cat_' . urlencode($cat)]];
    }
    $rows[] = [['text' => '❌ Batal', 'callback_data' => 'cancel']];
    return ['inline_keyboard' => $rows];
}

function talentKeyboard(): array {
    $conn    = db_connect();
    $res     = $conn->query("SELECT id, name FROM talents ORDER BY name ASC LIMIT 20");
    $talents = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    $conn->close();

    $rows = [];
    foreach ($talents as $t) {
        $rows[] = [['text' => $t['name'], 'callback_data' => 'talent_' . (int)$t['id']]];
    }
    if (empty($rows)) {
        $rows[] = [['text' => '⚠️ Belum ada talent', 'callback_data' => 'cancel']];
    }
    $rows[] = [['text' => '❌ Batal', 'callback_data' => 'cancel']];
    return ['inline_keyboard' => $rows];
}

function kategorPerformKeyboard(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '🎤 Solo', 'callback_data' => 'kp_Solo'],
                ['text' => '🎶 Duet', 'callback_data' => 'kp_Duet'],
            ],
            [['text' => '❌ Batal', 'callback_data' => 'cancel']],
        ]
    ];
}

function confirmLogKeyboard(): array {
    return [
        'inline_keyboard' => [
            [
                ['text' => '✅ Simpan',  'callback_data' => 'confirm_log'],
                ['text' => '❌ Batal',   'callback_data' => 'cancel'],
            ]
        ]
    ];
}

function cancelKeyboard(): array {
    return [
        'inline_keyboard' => [
            [['text' => '❌ Batal', 'callback_data' => 'cancel']]
        ]
    ];
}

function backKeyboard(): array {
    return [
        'inline_keyboard' => [
            [['text' => '🏠 Menu Utama', 'callback_data' => 'menu']]
        ]
    ];
}

// ============================================================
// Telegram API Helpers (Webhook Response)
// ============================================================

/** Balas dengan sendMessage biasa */
function tgReply(int $chat_id, string $html): void {
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'method'                   => 'sendMessage',
        'chat_id'                  => $chat_id,
        'text'                     => $html,
        'parse_mode'               => 'HTML',
        'disable_web_page_preview' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Balas dengan sendMessage + inline keyboard */
function tgReplyInline(int $chat_id, string $html, array $keyboard): void {
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'method'                   => 'sendMessage',
        'chat_id'                  => $chat_id,
        'text'                     => $html,
        'parse_mode'               => 'HTML',
        'disable_web_page_preview' => true,
        'reply_markup'             => $keyboard,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Edit pesan lama + update keyboard (untuk callback) */
function tgEditOrNew(int $chat_id, int $msg_id, string $html, array $keyboard): void {
    http_response_code(200);
    header('Content-Type: application/json');
    echo json_encode([
        'method'                   => 'editMessageText',
        'chat_id'                  => $chat_id,
        'message_id'               => $msg_id,
        'text'                     => $html,
        'parse_mode'               => 'HTML',
        'disable_web_page_preview' => true,
        'reply_markup'             => $keyboard,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Answer callback query (hapus loading spinner) */
function tgAnswerCallback(string $callback_id): void {
    // answerCallbackQuery dikirim via outbound request (fire-and-forget)
    // agar loading spinner di tombol hilang lebih cepat.
    // Jika curl/allow_url_fopen diblokir hosting, spinner hilang otomatis
    // setelah ~3 detik — bot tetap berfungsi normal.
    $url     = 'https://api.telegram.org/bot' . BOT_TOKEN . '/answerCallbackQuery';
    $payload = json_encode(['callback_query_id' => $callback_id]);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 3,
        ]);
        curl_exec($ch);
        curl_close($ch);
    } elseif (ini_get('allow_url_fopen')) {
        @file_get_contents($url, false, stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => 'Content-Type: application/json',
                'content' => $payload,
                'timeout' => 3,
            ]
        ]));
    }
    // Jika keduanya tidak tersedia, biarkan spinner hilang sendiri (harmless)
}

// ============================================================
// Command Functions (legacy text commands tetap berfungsi)
// ============================================================

/**
 * /add income|expense [kategori] [jumlah] [note...]
 */
function cmdAdd(array $parts): string {
    if (count($parts) < 4) {
        return
            "⚠️ <b>Format salah!</b>\n\n" .
            "✅ Format:\n" .
            "<code>/add income [kategori] [jumlah]</code>\n" .
            "<code>/add expense [kategori] [jumlah] [note]</code>\n\n" .
            "📝 Contoh:\n" .
            "<code>/add income topup 500000</code>\n" .
            "<code>/add expense gaji 300000 bulan april</code>\n\n" .
            "Atau gunakan tombol /menu untuk input via keyboard.";
    }

    $type     = strtolower($parts[1]);
    $category = $parts[2];
    $amount   = $parts[3];
    $note     = count($parts) > 4 ? implode(' ', array_slice($parts, 4)) : '';

    if (!in_array($type, ['income', 'expense'], true)) {
        return "⚠️ Tipe harus <b>income</b> atau <b>expense</b>.\nYang Anda kirim: <code>" . tgE($type) . "</code>";
    }
    if (!ctype_digit($amount) || (int)$amount <= 0) {
        return "⚠️ Jumlah harus angka bulat positif.\nYang Anda kirim: <code>" . tgE($amount) . "</code>";
    }

    $category = substr(strip_tags(trim($category)), 0, 100);
    if ($category === '') return "⚠️ Kategori tidak boleh kosong.";

    $note   = substr(strip_tags(trim($note)), 0, 500);
    $amount = (int)$amount;
    $date   = date('Y-m-d');

    $conn = db_connect();
    $stmt = $conn->prepare(
        "INSERT INTO transactions (type, category, amount, note, date) VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) { $conn->close(); return "❌ DB prepare error."; }
    $stmt->bind_param('ssiss', $type, $category, $amount, $note, $date);

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close(); $conn->close();
        error_log("Bot cmdAdd DB error: $err");
        return "❌ Gagal menyimpan transaksi.";
    }

    $id = (int)$conn->insert_id;
    $stmt->close(); $conn->close();

    $emoji = $type === 'income' ? '💰' : '💸';
    return
        "✅ <b>Transaksi Disimpan!</b>\n\n" .
        "$emoji Tipe     : <b>" . tgE(strtoupper($type)) . "</b>\n" .
        "📂 Kategori : " . tgE($category) . "\n" .
        "💵 Jumlah   : <b>Rp " . number_format($amount, 0, ',', '.') . "</b>\n" .
        "📅 Tanggal  : " . tgE($date) . "\n" .
        ($note !== '' ? "📝 Note     : " . tgE($note) . "\n" : '') .
        "\n🆔 ID: #$id";
}

/**
 * /log [talent_id] [views] [income] [followers] [room]
 *
 * Mapping ke kolom DB lama:
 *   views     → views
 *   income    → income
 *   followers → rating   (reuse kolom lama, maks 99999.99)
 *   room      → duration (reuse kolom lama, VARCHAR 50)
 *   perform   → '' (diisi via menu)
 */
function cmdLog(array $parts): string {
    if (count($parts) < 5) {
        return
            "⚠️ <b>Format salah!</b>\n\n" .
            "✅ Format:\n" .
            "<code>/log [talent_id] [views] [income] [followers_baru] [room]</code>\n\n" .
            "📝 Contoh:\n" .
            "<code>/log 1 500 200000 250 RoomVIP</code>\n\n" .
            "Atau gunakan /menu → 🎭 Log Talent untuk input step-by-step.\n\n" .
            "Lihat daftar talent: /listalent";
    }

    $talent_id      = (int)$parts[1];
    $views          = $parts[2];
    $income         = $parts[3];
    $followers_baru = $parts[4];
    $room           = count($parts) > 5 ? implode(' ', array_slice($parts, 5)) : '';

    if ($talent_id <= 0) return "⚠️ ID talent tidak valid. Harus angka &gt; 0.";
    if (!ctype_digit((string)$views))          return "⚠️ Views harus berupa angka ≥ 0.";
    if (!ctype_digit((string)$income))         return "⚠️ Income harus berupa angka ≥ 0.";
    if (!ctype_digit((string)$followers_baru)) return "⚠️ Followers Baru harus berupa angka ≥ 0.";

    $conn = db_connect();
    $st   = $conn->prepare("SELECT name FROM talents WHERE id = ?");
    if (!$st) { $conn->close(); return "❌ DB prepare error."; }
    $st->bind_param('i', $talent_id);
    $st->execute();
    $talent = $st->get_result()->fetch_assoc();
    $st->close();

    if (!$talent) {
        $conn->close();
        return "⚠️ Talent ID <b>$talent_id</b> tidak ditemukan.\nGunakan /listalent untuk melihat ID yang tersedia.";
    }

    $v_int    = (int)$views;
    $i_int    = (int)$income;
    $f_float  = (float)$followers_baru; // simpan ke rating (DECIMAL 5,2)
    $dur      = substr(strip_tags(trim($room)), 0, 50); // simpan ke duration
    $perform  = '';
    $log_date = date('Y-m-d');

    // INSERT ke schema lama: perform, views, income, rating(=followers), duration(=room)
    $stmt = $conn->prepare(
        "INSERT INTO talent_logs (talent_id, perform, views, income, rating, duration, log_date)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    if (!$stmt) { $conn->close(); return "❌ DB prepare error."; }
    $stmt->bind_param('isiidss', $talent_id, $perform, $v_int, $i_int, $f_float, $dur, $log_date);

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close(); $conn->close();
        error_log("Bot cmdLog DB error: $err");
        return "❌ Gagal menyimpan log.";
    }

    $id = (int)$conn->insert_id;
    $stmt->close(); $conn->close();

    return
        "✅ <b>Log Performa Disimpan!</b>\n\n" .
        "🎭 Talent         : <b>" . tgE($talent['name']) . "</b>\n" .
        "📅 Tanggal        : " . tgE($log_date) . "\n" .
        "👁 Views          : " . number_format($v_int) . "\n" .
        "💰 Income         : <b>Rp " . number_format($i_int, 0, ',', '.') . "</b>\n" .
        "👥 Followers Baru : " . number_format((int)$followers_baru) . "\n" .
        ($dur !== '' ? "🏠 Room           : " . tgE($dur) . "\n" : '') .
        "\n🆔 Log ID: #$id";
}

/**
 * /saldo — Saldo bersih termasuk modal awal
 */
function cmdSaldo(): string {
    $conn = db_connect();
    $res  = $conn->query("
        SELECT
          COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS income,
          COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS expense,
          COUNT(*) AS total_tx
        FROM transactions
    ");
    if (!$res) {
        error_log("Bot cmdSaldo DB error: " . $conn->error);
        $conn->close();
        return "❌ Gagal mengambil data saldo.";
    }
    $row = $res->fetch_assoc();

    $stmt_s = $conn->prepare("SELECT value FROM settings WHERE key_name = 'saldo_awal'");
    $saldo_awal = 0;
    if ($stmt_s) {
        $stmt_s->execute();
        $sr = $stmt_s->get_result()->fetch_assoc();
        $stmt_s->close();
        $saldo_awal = (int)($sr['value'] ?? 0);
    }
    $conn->close();

    $saldo = $saldo_awal + (int)$row['income'] - (int)$row['expense'];
    $emoji = $saldo >= 0 ? '🟢' : '🔴';

    return
        "💰 <b>SALDO KEUANGAN</b>\n" .
        "━━━━━━━━━━━━━━━━━\n" .
        "🏦 Modal Awal   : Rp " . number_format($saldo_awal, 0, ',', '.') . "\n" .
        "📈 Pemasukan    : Rp " . number_format((int)$row['income'],  0, ',', '.') . "\n" .
        "📉 Pengeluaran  : Rp " . number_format((int)$row['expense'], 0, ',', '.') . "\n" .
        "━━━━━━━━━━━━━━━━━\n" .
        "$emoji Saldo Bersih : <b>Rp " . number_format(abs($saldo), 0, ',', '.') . "</b>" .
        ($saldo < 0 ? " (DEFISIT)" : "") . "\n\n" .
        "📊 Total transaksi: " . (int)$row['total_tx'] . "\n" .
        "📅 " . date('d M Y H:i') . " WIB";
}

/**
 * /report — Laporan bulan ini
 */
function cmdReport(): string {
    $conn      = db_connect();
    $month     = date('Y-m');
    $month_lbl = date('F Y');

    $stmt = $conn->prepare("
        SELECT
          COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS income,
          COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS expense,
          COUNT(*) AS total_tx
        FROM transactions
        WHERE DATE_FORMAT(date,'%Y-%m') = ?
    ");
    if (!$stmt) { $conn->close(); return "❌ DB error."; }
    $stmt->bind_param('s', $month);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $stmt2 = $conn->prepare("
        SELECT category, SUM(amount) AS total
        FROM transactions
        WHERE type='expense' AND DATE_FORMAT(date,'%Y-%m') = ?
        GROUP BY category ORDER BY total DESC LIMIT 5
    ");
    if (!$stmt2) { $conn->close(); return "❌ DB error."; }
    $stmt2->bind_param('s', $month);
    $stmt2->execute();
    $cats = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt2->close();

    $stmt3 = $conn->prepare("
        SELECT COUNT(*) AS c, COALESCE(SUM(income),0) AS ti
        FROM talent_logs
        WHERE DATE_FORMAT(log_date,'%Y-%m') = ?
    ");
    if (!$stmt3) { $conn->close(); return "❌ DB error."; }
    $stmt3->bind_param('s', $month);
    $stmt3->execute();
    $tlog = $stmt3->get_result()->fetch_assoc();
    $stmt3->close();
    $conn->close();

    $saldo = (int)$row['income'] - (int)$row['expense'];
    $emoji = $saldo >= 0 ? '🟢' : '🔴';

    $cat_text = '';
    if (!empty($cats)) {
        $cat_text = "\n\n📂 <b>Top Pengeluaran:</b>\n";
        foreach ($cats as $c) {
            $cat_text .= "  • " . tgE($c['category']) . ": Rp " . number_format((int)$c['total'], 0, ',', '.') . "\n";
        }
    }

    return
        "📊 <b>LAPORAN BULAN INI</b>\n" .
        "📅 " . tgE($month_lbl) . "\n" .
        "━━━━━━━━━━━━━━━━━\n" .
        "💰 Pemasukan   : <b>Rp " . number_format((int)$row['income'],  0, ',', '.') . "</b>\n" .
        "💸 Pengeluaran : <b>Rp " . number_format((int)$row['expense'], 0, ',', '.') . "</b>\n" .
        "$emoji Saldo       : <b>Rp " . number_format(abs($saldo), 0, ',', '.') . "</b>" .
        ($saldo < 0 ? " (DEFISIT)" : "") . "\n" .
        "📋 Tx Count    : " . (int)$row['total_tx'] . " transaksi" .
        $cat_text .
        "\n\n🎭 <b>Talent Log:</b> " . (int)$tlog['c'] . " log | Income: Rp " . number_format((int)$tlog['ti'], 0, ',', '.');
}

/**
 * /listalent — Daftar talent + ID
 */
function cmdListTalent(): string {
    $conn = db_connect();
    $res  = $conn->query("SELECT id, name, role FROM talents ORDER BY name ASC LIMIT 20");
    if (!$res) { $conn->close(); return "❌ Gagal mengambil data talent."; }
    $talents = $res->fetch_all(MYSQLI_ASSOC);
    $conn->close();

    if (empty($talents)) {
        return "📭 Belum ada talent terdaftar.\nTambah via web dashboard.";
    }

    $list = "🎭 <b>DAFTAR TALENT</b>\n━━━━━━━━━━━━━━━━━\n";
    foreach ($talents as $t) {
        $role  = $t['role'] ? " — " . tgE($t['role']) : '';
        $list .= "ID <b>" . (int)$t['id'] . "</b> : " . tgE($t['name']) . $role . "\n";
    }
    $list .= "\nGunakan ID untuk command /log atau tombol 🎭 Log Talent di /menu";
    return $list;
}

/**
 * Teks menu utama
 */
function msgMenuText(): string {
    return
        "🤖 <b>FINANCE HQ BOT</b>\n" .
        "━━━━━━━━━━━━━━━━━\n" .
        "Pilih menu di bawah:";
}

